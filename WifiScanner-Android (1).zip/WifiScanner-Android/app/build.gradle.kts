plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("org.jetbrains.kotlin.plugin.serialization")
    id("com.google.devtools.ksp")
}

android {
    namespace = "com.example.wifiscanner"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.wifiscanner"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }

    packaging {
        resources {
            excludes += listOf(
                "/META-INF/{AL2.0,LGPL2.1}",
                "META-INF/versions/9/OSGI-INF/MANIFEST.MF",
                "META-INF/DEPENDENCIES",
                "META-INF/LICENSE",
                "META-INF/LICENSE.txt",
                "META-INF/NOTICE",
                "META-INF/NOTICE.txt"
            )
        }
    }
}

dependencies {
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.5")

    // Core AndroidX & Splash & AppCompat
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.core:core-splashscreen:1.0.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-compose:1.9.3")

    // Lifecycle & Jetpack Navigation Compose
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.navigation:navigation-compose:2.8.5")

    // Jetpack Compose BOM + Material 3 + Adaptive Window Size + Extended Icons
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material3:material3-window-size-class")
    implementation("androidx.compose.material:material-icons-extended")

    // JetBrains Kotlinx Powerhouse Libraries
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.3")
    implementation("org.jetbrains.kotlinx:kotlinx-collections-immutable:0.3.8")
    implementation("org.jetbrains.kotlinx:kotlinx-datetime:0.6.1")

    // Room SQLite Database + DataStore Preferences + WorkManager
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")
    implementation("androidx.datastore:datastore-preferences:1.1.1")
    implementation("androidx.work:work-runtime-ktx:2.10.0")

    // Android Hardware Security Crypto & Biometric Auth
    implementation("androidx.security:security-crypto:1.0.0")
    implementation("androidx.biometric:biometric:1.1.0")

    // Koin 4.0 Dependency Injection BOM
    implementation(platform("io.insert-koin:koin-bom:4.0.0"))
    implementation("io.insert-koin:koin-android")
    implementation("io.insert-koin:koin-androidx-compose")
    implementation("io.insert-koin:koin-androidx-compose-navigation")
    implementation("io.insert-koin:koin-androidx-workmanager")

    // === Multi-Layer Network Inspection & Vulnerability Confirmation Stack ===
    // 1. OkHttp 4 + DNS-over-HTTPS + TLS Cert/Pinning Inspection + Retrofit 2.11
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("com.squareup.okhttp3:logging-interceptor:4.12.0")
    implementation("com.squareup.okhttp3:okhttp-dnsoverhttps:4.12.0")
    implementation("com.squareup.okhttp3:okhttp-tls:4.12.0")
    implementation("com.squareup.retrofit2:retrofit:2.11.0")
    implementation("com.squareup.retrofit2:converter-kotlinx-serialization:2.11.0")

    // 2. Ktor Non-Blocking Raw TCP/UDP/TLS Socket Engine (SSDP/UPnP & Banner Confirmation)
    implementation("io.ktor:ktor-network:3.1.0")
    implementation("io.ktor:ktor-network-tls:3.1.0")

    // 3. DNS Protocol, DNSSEC Validation & Anti-Hijacking Cross-Check
    implementation("dnsjava:dnsjava:3.7.1")

    // 4. Local LAN mDNS / ZeroConf / Bonjour Service Discovery
    implementation("org.jmdns:jmdns:3.6.5")

    // 5. IPv4/IPv6 Subnet CIDR & MAC OUI / Locally-Administered BSSID Inspection
    implementation("com.github.seancfoley:ipaddress:5.6.2")

    // 6. Modern TLS 1.3 Engine & X.509 Cryptographic Weakness Verification
    implementation("org.conscrypt:conscrypt-android:2.9.0")
    implementation("org.bouncycastle:bcpkix-jdk18on:1.86")

    // 7. NTP Clock-Skew Guard & Protocol Utilities
    implementation("commons-net:commons-net:3.13.0")

    // UI Helpers & Diagnostics Logging
    implementation("io.coil-kt:coil-compose:2.7.0")
    implementation("com.airbnb.android:lottie-compose:6.6.0")
    implementation("com.google.accompanist:accompanist-permissions:0.36.0")
    implementation("com.jakewharton.timber:timber:5.0.1")
}
