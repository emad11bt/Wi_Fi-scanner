package com.example.wifiscanner

import android.content.Intent
import android.net.TrafficStats
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun NetworkDiagnosticsView(
    networks: List<WifiNetworkItem>,
    onSaveAuditToVault: (DeepAuditReport) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var linkInfo by remember { mutableStateOf(LocalNetworkDiagnostics.readActiveWifiLinkInfo(context)) }
    var pingReport by remember { mutableStateOf<PingReport?>(null) }
    var isPinging by remember { mutableStateOf(false) }

    var devices by remember { mutableStateOf<List<LanDevice>>(emptyList()) }
    var isDiscovering by remember { mutableStateOf(false) }
    var discoveryProgress by remember { mutableFloatStateOf(0f) }

    var scannedPortTarget by remember { mutableStateOf<String?>(null) }
    var openPorts by remember { mutableStateOf<List<LocalPortService>>(emptyList()) }
    var isScanningPorts by remember { mutableStateOf(false) }

    var deepReport by remember { mutableStateOf<DeepAuditReport?>(null) }
    var isRunningDeepAudit by remember { mutableStateOf(false) }
    var deepStageLabel by remember { mutableStateOf<String?>(null) }
    var deepProgress by remember { mutableFloatStateOf(0f) }
    var saveStatus by remember { mutableStateOf<String?>(null) }
    var isExportingPdf by remember { mutableStateOf(false) }
    var showCustomizePanel by remember { mutableStateOf(false) }
    var reportOptions by remember { mutableStateOf(ReportCustomizationOptions()) }
    var tlsPosture by remember { mutableStateOf<TlsAndDohPosture?>(null) }
    var isCheckingTls by remember { mutableStateOf(false) }
    var multiLayerResult by remember { mutableStateOf<MultiLayerAuditSummary?>(null) }
    var isRunningMultiLayer by remember { mutableStateOf(false) }

    var isLiveMonitoring by remember { mutableStateOf(false) }
    var liveMetrics by remember { mutableStateOf<LiveTrafficMetrics?>(null) }
    var baselineStatus by remember { mutableStateOf<String?>(null) }
    var startRxBytes by remember { mutableLongStateOf(0L) }
    var startTxBytes by remember { mutableLongStateOf(0L) }

    LaunchedEffect(isLiveMonitoring) {
        if (isLiveMonitoring) {
            val initRx = TrafficStats.getTotalRxBytes().coerceAtLeast(0L)
            val initTx = TrafficStats.getTotalTxBytes().coerceAtLeast(0L)
            startRxBytes = initRx
            startTxBytes = initTx
            var prevRx = initRx
            var prevTx = initTx
            while (isLiveMonitoring) {
                val (metrics, nextRx, nextTx) = NetworkSecurityMonitor.sampleTrafficAndPosture(
                    context = context,
                    prevRxBytes = prevRx,
                    prevTxBytes = prevTx,
                    startRxBytes = startRxBytes,
                    startTxBytes = startTxBytes
                )
                liveMetrics = metrics
                prevRx = nextRx
                prevTx = nextTx
                linkInfo = LocalNetworkDiagnostics.readActiveWifiLinkInfo(context)
                delay(1000L)
            }
        }
    }

    val liveFindings = remember(linkInfo, networks, openPorts, devices, liveMetrics) {
        NetworkSecurityMonitor.evaluateSecurityAndLeaks(
            context = context,
            linkInfo = linkInfo,
            scannedNetworks = networks,
            routerPorts = openPorts,
            lanDevices = devices
        )
    }

    val channelInsight = remember(networks) {
        DeepDiagnosticEngine.analyzeChannelCongestion(networks)
    }

    val activeExportReport = remember(
        deepReport,
        linkInfo,
        networks,
        pingReport,
        openPorts,
        devices
    ) {
        deepReport ?: DeepDiagnosticEngine.buildSnapshotReport(
            context = context,
            scannedNetworks = networks,
            linkInfo = linkInfo,
            pingReport = pingReport,
            routerPorts = openPorts,
            lanDevices = devices
        )
    }

    val savePdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        if (uri != null) {
            val reportToSave = activeExportReport
            scope.launch {
                isExportingPdf = true
                val result = withContext(Dispatchers.IO) {
                    runCatching {
                        context.contentResolver.openOutputStream(uri)?.use { stream ->
                            PdfReportGenerator.writePdf(reportToSave, reportOptions, stream)
                        } ?: error("Cannot open output stream")
                    }
                }
                isExportingPdf = false
                saveStatus = result.fold(
                    onSuccess = { "PDF report saved successfully." },
                    onFailure = { err -> "Could not save PDF report: ${err.message}" }
                )
            }
        }
    }

    val saveDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        if (uri != null) {
            val reportToSave = activeExportReport
            runCatching {
                val text = DeepDiagnosticEngine.formatReportText(reportToSave, reportOptions)
                context.contentResolver.openOutputStream(uri)?.use { stream ->
                    stream.write(text.toByteArray(Charsets.UTF_8))
                }
            }.onSuccess {
                saveStatus = "TXT report saved successfully."
            }.onFailure { err ->
                saveStatus = "Could not save report: ${err.message}"
            }
        }
    }

    val saveJsonLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            val reportToSave = activeExportReport
            runCatching {
                val json = DeepDiagnosticEngine.formatReportJson(reportToSave, reportOptions)
                context.contentResolver.openOutputStream(uri)?.use { stream ->
                    stream.write(json.toByteArray(Charsets.UTF_8))
                }
            }.onSuccess {
                saveStatus = "JSON report saved successfully."
            }.onFailure { err ->
                saveStatus = "Could not save JSON report: ${err.message}"
            }
        }
    }

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 0. Deep Defensive Diagnostic & Custom PDF Report Export Card
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "Deep Defensive Audit & PDF Report",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = channelInsight.summary,
                    style = MaterialTheme.typography.bodySmall
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        enabled = !isRunningDeepAudit,
                        onClick = {
                            scope.launch {
                                isRunningDeepAudit = true
                                saveStatus = null
                                val result = DeepDiagnosticEngine.runDeepDefensiveAudit(
                                    context = context,
                                    scannedNetworks = networks,
                                    onStageUpdate = { label, prog ->
                                        deepStageLabel = label
                                        deepProgress = prog
                                    }
                                )
                                deepReport = result
                                multiLayerResult = result.multiLayerSummary
                                onSaveAuditToVault(result)
                                linkInfo = result.linkInfo
                                if (result.pingReport != null) pingReport = result.pingReport
                                if (result.lanDevices.isNotEmpty()) devices = result.lanDevices
                                if (LocalNetworkDiagnostics.isPrivateIpv4(result.linkInfo.gatewayIp)) {
                                    scannedPortTarget = result.linkInfo.gatewayIp
                                    openPorts = result.routerPorts
                                }
                                isRunningDeepAudit = false
                            }
                        }
                    ) {
                        Text(if (isRunningDeepAudit) "Running Audit..." else "Run Deep Audit")
                    }

                    OutlinedButton(onClick = { showCustomizePanel = !showCustomizePanel }) {
                        Text(if (showCustomizePanel) "Hide Options" else "Customize Report")
                    }
                }

                if (isRunningDeepAudit) {
                    Spacer(modifier = Modifier.height(8.dp))
                    deepStageLabel?.let {
                        Text(text = it, style = MaterialTheme.typography.labelSmall)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = { deepProgress },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                AnimatedVisibility(visible = showCustomizePanel) {
                    Column(modifier = Modifier.padding(top = 12.dp)) {
                        HorizontalDivider()
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Customize Report Content",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        OutlinedTextField(
                            value = reportOptions.customTitle,
                            onValueChange = { reportOptions = reportOptions.copy(customTitle = it) },
                            label = { Text("Report Title") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = reportOptions.inspectorNote,
                            onValueChange = { reportOptions = reportOptions.copy(inspectorNote = it) },
                            label = { Text("Location / Note (Optional)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Minimum Severity Included:",
                            style = MaterialTheme.typography.labelMedium
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf(
                                SecuritySeverity.SAFE to "All",
                                SecuritySeverity.MEDIUM to "Medium+",
                                SecuritySeverity.HIGH to "High+",
                                SecuritySeverity.CRITICAL to "Critical Only"
                            ).forEach { (sev, label) ->
                                FilterChip(
                                    selected = reportOptions.minSeverity == sev,
                                    onClick = { reportOptions = reportOptions.copy(minSeverity = sev) },
                                    label = { Text(label) }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = {
                                reportOptions = reportOptions.copy(
                                    includeActiveLink = true,
                                    includeChannelAnalysis = true,
                                    includeGatewayPing = true,
                                    includeOpenPorts = true,
                                    includeLanDevices = true,
                                    includeNearbyWifi = true,
                                    includeMonitorFindings = true,
                                    includeRecommendations = true,
                                    minSeverity = SecuritySeverity.SAFE
                                )
                            }) {
                                Text("Select All")
                            }
                            OutlinedButton(onClick = {
                                reportOptions = reportOptions.copy(
                                    includeActiveLink = true,
                                    includeChannelAnalysis = false,
                                    includeGatewayPing = false,
                                    includeOpenPorts = true,
                                    includeLanDevices = false,
                                    includeNearbyWifi = false,
                                    includeMonitorFindings = true,
                                    includeRecommendations = true,
                                    minSeverity = SecuritySeverity.MEDIUM
                                )
                            }) {
                                Text("Risks Only")
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        ReportOptionCheckbox(
                            label = "Active Wi-Fi Link & DNS Details",
                            checked = reportOptions.includeActiveLink,
                            onCheckedChange = { reportOptions = reportOptions.copy(includeActiveLink = it) }
                        )
                        ReportOptionCheckbox(
                            label = "RF Channel Congestion Analysis",
                            checked = reportOptions.includeChannelAnalysis,
                            onCheckedChange = { reportOptions = reportOptions.copy(includeChannelAnalysis = it) }
                        )
                        ReportOptionCheckbox(
                            label = "Gateway Ping & Jitter Stability",
                            checked = reportOptions.includeGatewayPing,
                            onCheckedChange = { reportOptions = reportOptions.copy(includeGatewayPing = it) }
                        )
                        ReportOptionCheckbox(
                            label = "Local Gateway Open Ports",
                            checked = reportOptions.includeOpenPorts,
                            onCheckedChange = { reportOptions = reportOptions.copy(includeOpenPorts = it) }
                        )
                        ReportOptionCheckbox(
                            label = "Discovered LAN Devices",
                            checked = reportOptions.includeLanDevices,
                            onCheckedChange = { reportOptions = reportOptions.copy(includeLanDevices = it) }
                        )
                        ReportOptionCheckbox(
                            label = "Nearby Wi-Fi Security Summary",
                            checked = reportOptions.includeNearbyWifi,
                            onCheckedChange = { reportOptions = reportOptions.copy(includeNearbyWifi = it) }
                        )
                        ReportOptionCheckbox(
                            label = "Multi-Layer Protocol & Vulnerability Confirmation",
                            checked = reportOptions.includeMultiLayerPosture,
                            onCheckedChange = { reportOptions = reportOptions.copy(includeMultiLayerPosture = it) }
                        )
                        ReportOptionCheckbox(
                            label = "Security & Leak Findings",
                            checked = reportOptions.includeMonitorFindings,
                            onCheckedChange = { reportOptions = reportOptions.copy(includeMonitorFindings = it) }
                        )
                        ReportOptionCheckbox(
                            label = "Defensive Recommendations",
                            checked = reportOptions.includeRecommendations,
                            onCheckedChange = { reportOptions = reportOptions.copy(includeRecommendations = it) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider()
                Spacer(modifier = Modifier.height(8.dp))

                deepReport?.let { report ->
                    if (reportOptions.includeRecommendations) {
                        Text(
                            text = "Recommendations (${report.recommendations.size})",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.SemiBold
                        )
                        report.recommendations.forEach { rec ->
                            Text(text = "- $rec", style = MaterialTheme.typography.bodySmall)
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                    }
                }

                Text(
                    text = if (deepReport != null) {
                        "Export Customized Deep Audit Report:"
                    } else {
                        "Export Current Scan Snapshot (or Run Deep Audit for full LAN & ping data):"
                    },
                    style = MaterialTheme.typography.labelMedium
                )
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        enabled = !isExportingPdf,
                        onClick = {
                            savePdfLauncher.launch("wifi-security-report.pdf")
                        }
                    ) {
                        Text(if (isExportingPdf) "Creating PDF..." else "Export PDF")
                    }
                    OutlinedButton(
                        enabled = !isExportingPdf,
                        onClick = {
                            val reportToShare = activeExportReport
                            scope.launch {
                                isExportingPdf = true
                                val uriResult = withContext(Dispatchers.IO) {
                                    runCatching {
                                        PdfReportGenerator.createShareablePdfUri(
                                            context = context,
                                            report = reportToShare,
                                            options = reportOptions
                                        )
                                    }
                                }
                                isExportingPdf = false
                                uriResult.onSuccess { pdfUri ->
                                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "application/pdf"
                                        putExtra(Intent.EXTRA_SUBJECT, reportOptions.customTitle.ifBlank { "Wi-Fi Security Audit Report" })
                                        putExtra(Intent.EXTRA_STREAM, pdfUri)
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    context.startActivity(Intent.createChooser(shareIntent, "Share PDF Report"))
                                }.onFailure { err ->
                                    saveStatus = "Could not share PDF: ${err.message}"
                                }
                            }
                        }
                    ) {
                        Text("Share PDF")
                    }
                    OutlinedButton(onClick = {
                        saveDocumentLauncher.launch("wifi-security-report.txt")
                    }) {
                        Text("Save TXT")
                    }
                    OutlinedButton(onClick = {
                        saveJsonLauncher.launch("wifi-security-report.json")
                    }) {
                        Text("Save JSON")
                    }
                }

                saveStatus?.let {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = it, style = MaterialTheme.typography.labelSmall)
                }
            }
        }

        // 0a. Visual Report Analytics Charts
        SeverityBreakdownChartCard(findings = activeExportReport.monitorFindings)
        ChannelCongestionChartCard(channelReport = channelInsight)
        activeExportReport.pingReport?.let { pReport ->
            PingLatencyChartCard(
                pingReport = pReport,
                jitterMs = activeExportReport.jitterMs
            )
        }

        // 0a-extra. Multi-Layer Protocol & Vulnerability Confirmation Card
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "Multi-Layer Protocol & Vulnerability Verification",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Uses IPAddress, dnsjava (DNSSEC), JmDNS (ZeroConf), Ktor (SSDP & TCP Banners), Conscrypt + BouncyCastle (X.509), and Commons-Net (NTP).",
                    style = MaterialTheme.typography.bodySmall
                )
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    enabled = !isRunningMultiLayer,
                    onClick = {
                        scope.launch {
                            isRunningMultiLayer = true
                            multiLayerResult = MultiLayerNetworkInspector.runMultiLayerInspection(
                                context = context,
                                linkInfo = linkInfo,
                                scannedNetworks = networks,
                                routerPorts = openPorts
                            )
                            isRunningMultiLayer = false
                        }
                    }
                ) {
                    Text(if (isRunningMultiLayer) "Verifying Protocols..." else "Run Multi-Layer Scan")
                }

                multiLayerResult?.let { ml ->
                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider()
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Subnet CIDR: ${ml.subnetCidr} (${ml.ipScopeLabel})", style = MaterialTheme.typography.bodySmall)
                    Text("DNS & DNSSEC: ${ml.dnsSecuritySummary}", style = MaterialTheme.typography.bodySmall)
                    Text("Gateway X.509/TLS: ${ml.gatewayCertSummary}", style = MaterialTheme.typography.bodySmall)
                    Text(
                        "NTP Clock Drift: ${ml.ntpClockDriftSeconds?.let { "${it}s" } ?: "Offline / Unchecked"}",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        "mDNS Services (${ml.mdnsServicesCount}): ${ml.mdnsServicesSample.joinToString(", ").ifBlank { "None" }}",
                        style = MaterialTheme.typography.bodySmall
                    )
                    if (ml.ssdpUpnpResponders.isNotEmpty()) {
                        Text(
                            "SSDP/UPnP Responders: ${ml.ssdpUpnpResponders.joinToString(" | ")}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    if (ml.confirmedPortBanners.isNotEmpty()) {
                        Text(
                            "Confirmed Port Banners: ${ml.confirmedPortBanners.joinToString(" | ")}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    if (ml.findings.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        ml.findings.forEach { f ->
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "[${f.verification.label}] [${f.severity.label}] ${f.title}",
                                color = diagnosticSeverityColor(f.severity),
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(text = f.detail, style = MaterialTheme.typography.bodySmall)
                            Text(text = "Fix: ${f.remediation}", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }

        // 0b. Live Network Traffic, Leak & Intrusion Monitor
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "Live Network Monitor & Leak Watch",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(onClick = { isLiveMonitoring = !isLiveMonitoring }) {
                        Text(if (isLiveMonitoring) "Stop Live Monitor" else "Start Live Monitor")
                    }
                    OutlinedButton(
                        enabled = !isCheckingTls,
                        onClick = {
                            scope.launch {
                                isCheckingTls = true
                                tlsPosture = ModernTlsAndDnsInspector.inspectPosture(linkInfo.gatewayIp)
                                isCheckingTls = false
                            }
                        }
                    ) {
                        Text(if (isCheckingTls) "Inspecting..." else "TLS & DoH Check")
                    }
                    OutlinedButton(
                        enabled = networks.isNotEmpty() || devices.isNotEmpty(),
                        onClick = {
                            val wifiCount = NetworkSecurityMonitor.saveTrustedWifiBaseline(context, networks)
                            val lanCount = NetworkSecurityMonitor.saveTrustedLanDevices(context, devices)
                            baselineStatus = "Encrypted baseline saved: $wifiCount Wi-Fi APs, $lanCount LAN devices."
                        }
                    ) {
                        Text("Trust Baseline")
                    }
                }

                tlsPosture?.let { tls ->
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "OkHttp TLS: ${tls.dohTlsVersion} · ${tls.dohCipherSuite}",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "DoH Resolver: ${tls.dohStatus} (${tls.dohLatencyMs ?: "-"} ms)",
                        style = MaterialTheme.typography.labelSmall
                    )
                    Text(
                        text = "Gateway HTTPS: ${tls.gatewayHttpsStatus}",
                        style = MaterialTheme.typography.labelSmall
                    )
                }

                baselineStatus?.let {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = it, style = MaterialTheme.typography.labelSmall)
                }

                liveMetrics?.let { m ->
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Live Traffic -> Down: ${m.rxBytesPerSec / 1024} KB/s · Up: ${m.txBytesPerSec / 1024} KB/s",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "Session Total -> Down: ${m.sessionRxKb} KB · Up: ${m.sessionTxKb} KB",
                        style = MaterialTheme.typography.labelSmall
                    )
                    Text(
                        text = "Private DNS (DoT): ${if (m.isPrivateDnsActive) "Active (${m.privateDnsHost ?: "Auto"})" else "Disabled (Unencrypted DNS)"}",
                        style = MaterialTheme.typography.labelSmall
                    )
                    Text(
                        text = "HTTP Proxy: ${m.httpProxyHost ?: "None"} · Captive Portal: ${if (m.isCaptivePortal) "Yes" else "No"}",
                        style = MaterialTheme.typography.labelSmall
                    )
                }

                if (liveFindings.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider()
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Findings (Lowest -> Critical):",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.SemiBold
                    )
                    liveFindings.forEach { f ->
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "[${f.severity.label}] ${f.title}",
                            color = diagnosticSeverityColor(f.severity),
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(text = f.description, style = MaterialTheme.typography.bodySmall)
                        Text(
                            text = "Fix: ${f.remediation}",
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
            }
        }

        // 1. Active Wi-Fi Connection & Protocol Card
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Active Wi-Fi Link",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    OutlinedButton(onClick = {
                        linkInfo = LocalNetworkDiagnostics.readActiveWifiLinkInfo(context)
                    }) {
                        Text("Refresh")
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text("SSID: ${linkInfo.ssid}", style = MaterialTheme.typography.bodyMedium)
                Text("Protocol: ${linkInfo.securityProtocol}", style = MaterialTheme.typography.bodySmall)
                Text("Standard: ${linkInfo.wifiStandard}", style = MaterialTheme.typography.bodySmall)
                Text(
                    "Link: ${linkInfo.linkSpeedMbps} Mbps · ${linkInfo.frequencyMhz} MHz · ${linkInfo.rssiDbm} dBm",
                    style = MaterialTheme.typography.bodySmall
                )
                Text("Local IP: ${linkInfo.localIp}", style = MaterialTheme.typography.bodySmall)
                Text("Gateway: ${linkInfo.gatewayIp}", style = MaterialTheme.typography.bodySmall)
                if (linkInfo.dnsServers.isNotEmpty()) {
                    Text(
                        "DNS: ${linkInfo.dnsServers.joinToString(", ")}",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        // 2. Gateway Ping & Stability Monitor
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "Gateway Ping & Stability",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        enabled = linkInfo.isWifiConnected && !isPinging &&
                            LocalNetworkDiagnostics.isPrivateIpv4(linkInfo.gatewayIp),
                        onClick = {
                            scope.launch {
                                isPinging = true
                                pingReport = LocalNetworkDiagnostics.pingLocalHost(linkInfo.gatewayIp, 4)
                                isPinging = false
                            }
                        }
                    ) {
                        Text(if (isPinging) "Pinging..." else "Ping Gateway (${linkInfo.gatewayIp})")
                    }

                    OutlinedButton(
                        enabled = linkInfo.isWifiConnected && !isScanningPorts &&
                            LocalNetworkDiagnostics.isPrivateIpv4(linkInfo.gatewayIp),
                        onClick = {
                            scope.launch {
                                isScanningPorts = true
                                scannedPortTarget = linkInfo.gatewayIp
                                openPorts = LocalNetworkDiagnostics.scanCommonLocalPorts(linkInfo.gatewayIp)
                                isScanningPorts = false
                            }
                        }
                    ) {
                        Text(if (isScanningPorts) "Checking..." else "Check Router Ports")
                    }
                }

                pingReport?.let { report ->
                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider()
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Target: ${report.targetHost} · Loss: ${report.packetLossPercent}%",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "Min: ${report.minMs ?: "-"} ms · Avg: ${report.avgMs ?: "-"} ms · Max: ${report.maxMs ?: "-"} ms",
                        style = MaterialTheme.typography.bodySmall
                    )
                    report.samples.forEach { s ->
                        Text(
                            text = if (s.reachable) {
                                "Seq ${s.sequence}: ${s.rttMs} ms (${s.method})"
                            } else {
                                "Seq ${s.sequence}: Timeout"
                            },
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
            }
        }

        // 3. Local Port Audit Results
        scannedPortTarget?.let { target ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Open Local Ports on $target",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    if (isScanningPorts) {
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    } else if (openPorts.isEmpty()) {
                        Text(
                            text = "No common management/service ports responded on $target.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    } else {
                        openPorts.forEach { portInfo ->
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Port ${portInfo.port} (${portInfo.serviceName}) - ${portInfo.severity.label}",
                                color = diagnosticSeverityColor(portInfo.severity),
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = portInfo.advice,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }
        }

        // 4. Local Subnet Device Discovery
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "Local Network Devices (LAN Discovery)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Button(
                    enabled = linkInfo.isWifiConnected && !isDiscovering &&
                        LocalNetworkDiagnostics.isPrivateIpv4(linkInfo.localIp),
                    onClick = {
                        scope.launch {
                            isDiscovering = true
                            discoveryProgress = 0f
                            devices = LocalNetworkDiagnostics.discoverLocalSubnetDevices(
                                localIp = linkInfo.localIp,
                                gatewayIp = linkInfo.gatewayIp,
                                onProgress = { p -> discoveryProgress = p }
                            )
                            isDiscovering = false
                        }
                    }
                ) {
                    Text(if (isDiscovering) "Scanning Subnet..." else "Discover LAN Devices")
                }

                if (isDiscovering) {
                    Spacer(modifier = Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { discoveryProgress },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                if (devices.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Found ${devices.size} reachable hosts on local subnet:",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Medium
                    )
                    devices.forEach { dev ->
                        Spacer(modifier = Modifier.height(8.dp))
                        HorizontalDivider()
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                val tag = when {
                                    dev.isGateway -> " [Router / Gateway]"
                                    dev.isThisDevice -> " [This Phone]"
                                    else -> ""
                                }
                                Text(
                                    text = "${dev.ipAddress}$tag",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "${dev.hostName} · ${dev.latencyMs} ms",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                            OutlinedButton(
                                enabled = !isScanningPorts,
                                onClick = {
                                    scope.launch {
                                        isScanningPorts = true
                                        scannedPortTarget = dev.ipAddress
                                        openPorts = LocalNetworkDiagnostics.scanCommonLocalPorts(dev.ipAddress)
                                        isScanningPorts = false
                                    }
                                }
                            ) {
                                Text("Ports")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ReportOptionCheckbox(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) },
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(
            checked = checked,
            onCheckedChange = onCheckedChange
        )
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall
        )
    }
}

private fun diagnosticSeverityColor(severity: SecuritySeverity): Color {
    return when (severity) {
        SecuritySeverity.CRITICAL -> Color(0xFFB91C1C)
        SecuritySeverity.HIGH -> Color(0xFFC2410C)
        SecuritySeverity.MEDIUM -> Color(0xFFB45309)
        SecuritySeverity.LOW -> Color(0xFF1D4ED8)
        SecuritySeverity.SAFE -> Color(0xFF15803D)
    }
}
