package com.example.wifiscanner

import android.content.Context
import android.net.wifi.WifiManager
import inet.ipaddr.IPAddressString
import inet.ipaddr.mac.MACAddressString
import io.ktor.network.selector.SelectorManager
import io.ktor.network.sockets.Datagram
import io.ktor.network.sockets.InetSocketAddress
import io.ktor.network.sockets.aSocket
import io.ktor.network.sockets.openReadChannel
import io.ktor.network.sockets.openWriteChannel
import io.ktor.utils.io.core.BytePacketBuilder
import io.ktor.utils.io.core.readText
import io.ktor.utils.io.core.writeFully
import io.ktor.utils.io.readUTF8Line
import io.ktor.utils.io.writeStringUtf8
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.serialization.Serializable
import okhttp3.CertificatePinner
import org.apache.commons.net.ntp.NTPUDPClient
import org.bouncycastle.cert.jcajce.JcaX509CertificateHolder
import org.conscrypt.Conscrypt
import org.xbill.DNS.ARecord
import org.xbill.DNS.DClass
import org.xbill.DNS.ExtendedFlags
import org.xbill.DNS.Flags
import org.xbill.DNS.Message
import org.xbill.DNS.Name
import org.xbill.DNS.Record
import org.xbill.DNS.Section
import org.xbill.DNS.SimpleResolver
import org.xbill.DNS.Type
import timber.log.Timber
import java.net.InetAddress
import java.security.SecureRandom
import java.security.Security
import java.security.cert.X509Certificate
import java.security.interfaces.ECPublicKey
import java.security.interfaces.RSAPublicKey
import java.time.Duration
import java.util.Date
import javax.jmdns.JmDNS
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import javax.net.ssl.X509TrustManager
import kotlin.math.abs

@Serializable
enum class FindingVerification(val label: String) {
    CONFIRMED("Confirmed"),
    POTENTIAL("Predicted / Potential"),
    VERIFIED_SAFE("Verified Safe")
}

@Serializable
data class MultiLayerFinding(
    val layer: String,
    val title: String,
    val detail: String,
    val verification: FindingVerification,
    val severity: SecuritySeverity,
    val remediation: String
)

@Serializable
data class MultiLayerAuditSummary(
    val subnetCidr: String,
    val ipScopeLabel: String,
    val dnsSecuritySummary: String,
    val ntpClockDriftSeconds: Long?,
    val gatewayCertSummary: String,
    val mdnsServicesCount: Int,
    val mdnsServicesSample: List<String>,
    val ssdpUpnpResponders: List<String>,
    val confirmedPortBanners: List<String>,
    val findings: List<MultiLayerFinding>
)

object MultiLayerNetworkInspector {

    suspend fun runMultiLayerInspection(
        context: Context,
        linkInfo: ActiveWifiLinkInfo,
        scannedNetworks: List<WifiNetworkItem>,
        routerPorts: List<LocalPortService>
    ): MultiLayerAuditSummary = withContext(Dispatchers.IO) {
        val findings = mutableListOf<MultiLayerFinding>()

        // 1. Layer 2/3 IP & MAC Analysis (seancfoley ipaddress)
        val (subnetCidr, ipScopeLabel) = inspectIpAndSubnet(linkInfo, scannedNetworks, findings)

        // 2. DNSSEC & Anti-Hijacking Verification (dnsjava)
        val dnsSummary = inspectDnsIntegrity(linkInfo, findings)

        // 3. NTP Clock-Skew Check (Apache Commons Net)
        val ntpDriftSec = inspectNtpClockDrift(findings)

        // 4. Local Gateway X.509 & Cipher Analysis (Conscrypt + BouncyCastle + OkHttp CertificatePinner)
        val certSummary = inspectGatewayTlsCertificate(linkInfo.gatewayIp, findings)

        // 5. Local LAN mDNS / ZeroConf Discovery (JmDNS)
        val mdnsList = discoverMdnsServices(context, linkInfo.localIp, findings)

        // 6. UDP SSDP / UPnP Gateway Discovery (Ktor Network UDP)
        val ssdpList = probeSsdpUpnpResponders(linkInfo.isWifiConnected, findings)

        // 7. Safe TCP Service Banner Confirmation (Ktor Network TCP)
        val banners = confirmOpenPortBanners(linkInfo.gatewayIp, routerPorts, findings)

        MultiLayerAuditSummary(
            subnetCidr = subnetCidr,
            ipScopeLabel = ipScopeLabel,
            dnsSecuritySummary = dnsSummary,
            ntpClockDriftSeconds = ntpDriftSec,
            gatewayCertSummary = certSummary,
            mdnsServicesCount = mdnsList.size,
            mdnsServicesSample = mdnsList.take(8),
            ssdpUpnpResponders = ssdpList,
            confirmedPortBanners = banners,
            findings = findings.sortedBy { it.severity.priority }
        )
    }

    private fun inspectIpAndSubnet(
        linkInfo: ActiveWifiLinkInfo,
        scannedNetworks: List<WifiNetworkItem>,
        findings: MutableList<MultiLayerFinding>
    ): Pair<String, String> {
        if (!linkInfo.isWifiConnected || linkInfo.localIp == "-") {
            return "-" to "Not connected to Wi-Fi"
        }

        val cidrResult = runCatching {
            val addr = IPAddressString("${linkInfo.localIp}/24").address
            val block = addr?.toPrefixBlock()?.toString() ?: "${linkInfo.localIp}/24"
            val scope = when {
                addr == null -> "Unknown"
                addr.isLinkLocal -> "Link-Local (169.254.0.0/16 — possible DHCP failure)"
                addr.isLocal -> "Private RFC-1918 LAN"
                else -> "Public / Non-Private Assignment"
            }
            if (addr?.isLinkLocal == true) {
                findings += MultiLayerFinding(
                    layer = "Layer 3 / IP",
                    title = "Link-Local IPv4 Address Assigned (${linkInfo.localIp})",
                    detail = "Device received a 169.254.x.x APIPA address instead of a normal router DHCP lease.",
                    verification = FindingVerification.CONFIRMED,
                    severity = SecuritySeverity.MEDIUM,
                    remediation = "Reconnect to Wi-Fi or check router DHCP server pool availability."
                )
            }
            block to scope
        }.getOrElse { "${linkInfo.localIp}/24" to "Standard IPv4" }

        // Check locally-administered / randomized BSSIDs among nearby APs
        val localAdminCount = scannedNetworks.count { net ->
            runCatching {
                MACAddressString(net.bssid).address?.isLocal == true
            }.getOrDefault(false)
        }
        if (localAdminCount > 0) {
            findings += MultiLayerFinding(
                layer = "Layer 2 / MAC",
                title = "$localAdminCount Nearby AP(s) Use Locally-Administered BSSID",
                detail = "Detected Wi-Fi BSSID(s) with the locally-administered MAC bit set (typical of mobile hotspots, mesh virtual VAPs, or potential spoofed APs).",
                verification = FindingVerification.POTENTIAL,
                severity = SecuritySeverity.LOW,
                remediation = "Verify that the SSID matches an expected router/hotspot before auto-connecting."
            )
        }

        return cidrResult
    }

    private fun inspectDnsIntegrity(
        linkInfo: ActiveWifiLinkInfo,
        findings: MutableList<MultiLayerFinding>
    ): String {
        val localDns = linkInfo.dnsServers.firstOrNull { it.contains(".") }
            ?: return "No IPv4 DNS server reported on link"

        return runCatching {
            val localResolver = SimpleResolver(InetAddress.getByName(localDns)).apply {
                timeout = Duration.ofSeconds(2)
                setEDNS(0, 0, ExtendedFlags.DO)
            }
            val refResolver = SimpleResolver(InetAddress.getByName("1.1.1.1")).apply {
                timeout = Duration.ofSeconds(2)
                setEDNS(0, 0, ExtendedFlags.DO)
            }

            val queryName = Name.fromString("cloudflare.com.")
            val q1 = Message.newQuery(Record.newRecord(queryName, Type.A, DClass.IN))
            val q2 = Message.newQuery(Record.newRecord(queryName, Type.A, DClass.IN))

            val localResp = localResolver.send(q1)
            val refResp = refResolver.send(q2)

            val localIps = localResp.getSection(Section.ANSWER)
                .filterIsInstance<ARecord>()
                .mapNotNull { it.address?.hostAddress }
                .toSet()
            val refIps = refResp.getSection(Section.ANSWER)
                .filterIsInstance<ARecord>()
                .mapNotNull { it.address?.hostAddress }
                .toSet()
            val dnssecValidated = localResp.header.getFlag(Flags.AD.toInt())

            if (localIps.isNotEmpty() && refIps.isNotEmpty() && localIps.intersect(refIps).isEmpty()) {
                findings += MultiLayerFinding(
                    layer = "DNS / Hijack",
                    title = "DNS Interception / Spoofing Confirmed on $localDns",
                    detail = "Local DNS returned ${localIps.joinToString()} for cloudflare.com while 1.1.1.1 returned ${refIps.joinToString()}.",
                    verification = FindingVerification.CONFIRMED,
                    severity = SecuritySeverity.HIGH,
                    remediation = "Enable Android Private DNS (DoT) or switch router upstream DNS to 1.1.1.1 / 9.9.9.9."
                )
                "Hijack/Mismatch vs 1.1.1.1 on $localDns"
            } else {
                if (!dnssecValidated) {
                    findings += MultiLayerFinding(
                        layer = "DNS / DNSSEC",
                        title = "Local DNS ($localDns) Did Not Return DNSSEC AD Flag",
                        detail = "Active DNS answers matched reference IPs, but DNSSEC Authenticated Data (AD) was not set by the local resolver.",
                        verification = FindingVerification.POTENTIAL,
                        severity = SecuritySeverity.LOW,
                        remediation = "Use a DNSSEC-validating resolver (e.g. 1.1.1.1, 9.9.9.9) or Android Private DNS."
                    )
                } else {
                    findings += MultiLayerFinding(
                        layer = "DNS / DNSSEC",
                        title = "DNS Integrity & DNSSEC Verified on $localDns",
                        detail = "Local resolver matched reference answers and signaled DNSSEC validation.",
                        verification = FindingVerification.VERIFIED_SAFE,
                        severity = SecuritySeverity.SAFE,
                        remediation = "No action required."
                    )
                }
                "Matched 1.1.1.1 · DNSSEC AD=$dnssecValidated ($localDns)"
            }
        }.getOrElse { err ->
            Timber.w(err, "dnsjava cross-check failed")
            "Cross-check skipped (${err.javaClass.simpleName})"
        }
    }

    private fun inspectNtpClockDrift(findings: MutableList<MultiLayerFinding>): Long? {
        return runCatching {
            val client = NTPUDPClient().apply {
                setDefaultTimeout(Duration.ofMillis(2000))
            }
            client.open()
            try {
                val info = client.getTime(InetAddress.getByName("time.cloudflare.com"))
                info.computeDetails()
                val offsetMs = info.offset ?: 0L
                val driftSec = abs(offsetMs / 1000L)
                if (driftSec > 180L) {
                    findings += MultiLayerFinding(
                        layer = "Time / NTP",
                        title = "System Clock Drift Detected (${driftSec}s)",
                        detail = "Significant clock skew causes false-positive TLS expiry errors and weakens DNSSEC/token validation.",
                        verification = FindingVerification.CONFIRMED,
                        severity = SecuritySeverity.MEDIUM,
                        remediation = "Enable Automatic Date & Time in Android System Settings."
                    )
                }
                driftSec
            } finally {
                client.close()
            }
        }.getOrNull()
    }

    private fun inspectGatewayTlsCertificate(
        gatewayIp: String,
        findings: MutableList<MultiLayerFinding>
    ): String {
        if (!LocalNetworkDiagnostics.isPrivateIpv4(gatewayIp)) {
            return "No private Wi-Fi gateway active"
        }

        // Probe local RFC-1918 router HTTPS strictly to inspect its X.509 certificate metadata
        var capturedCert: X509Certificate? = null
        var trustVerifiedBySystem = true
        var negotiatedProtocol = "-"
        var negotiatedCipher = "-"

        runCatching {
            runCatching { Security.insertProviderAt(Conscrypt.newProvider(), 1) }

            val captureManager = object : X509TrustManager {
                override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) = Unit
                override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {
                    capturedCert = chain?.firstOrNull()
                }
                override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
            }

            // Standard check first
            val defaultCtx = SSLContext.getInstance("TLS")
            defaultCtx.init(null, null, SecureRandom())
            runCatching {
                (defaultCtx.socketFactory.createSocket() as SSLSocket).use { sock ->
                    sock.connect(java.net.InetSocketAddress(gatewayIp, 443), 1200)
                    sock.soTimeout = 1200
                    sock.startHandshake()
                    negotiatedProtocol = sock.session.protocol
                    negotiatedCipher = sock.session.cipherSuite
                    capturedCert = sock.session.peerCertificates.firstOrNull() as? X509Certificate
                }
            }.onFailure {
                trustVerifiedBySystem = false
                val inspectCtx = SSLContext.getInstance("TLS")
                inspectCtx.init(null, arrayOf(captureManager), SecureRandom())
                (inspectCtx.socketFactory.createSocket() as SSLSocket).use { sock ->
                    sock.connect(java.net.InetSocketAddress(gatewayIp, 443), 1200)
                    sock.soTimeout = 1200
                    sock.startHandshake()
                    negotiatedProtocol = sock.session.protocol
                    negotiatedCipher = sock.session.cipherSuite
                }
            }
        }

        val cert = capturedCert ?: return "Gateway HTTPS (443) not responding"
        val holder = runCatching { JcaX509CertificateHolder(cert) }.getOrNull()
        val sigAlg = cert.sigAlgName ?: "Unknown"
        val keyBits = when (val pk = cert.publicKey) {
            is RSAPublicKey -> pk.modulus.bitLength()
            is ECPublicKey -> pk.params?.order?.bitLength() ?: 256
            else -> 0
        }
        val spkiPin = runCatching { CertificatePinner.pin(cert) }.getOrDefault("-")
        val now = Date()
        val isExpired = now.after(cert.notAfter) || now.before(cert.notBefore)
        val isWeakSig = sigAlg.contains("SHA1", ignoreCase = true) || sigAlg.contains("MD5", ignoreCase = true)
        val isWeakKey = cert.publicKey is RSAPublicKey && keyBits in 1..2047
        val isSelfSigned = holder != null && holder.issuer == holder.subject

        if (isWeakSig || isWeakKey || isExpired) {
            findings += MultiLayerFinding(
                layer = "TLS / X.509",
                title = "Confirmed Weak Gateway HTTPS Certificate ($sigAlg, ${keyBits}-bit)",
                detail = "Router HTTPS cert has weak signature/key or invalid date window (Expired=$isExpired, Pin=$spkiPin).",
                verification = FindingVerification.CONFIRMED,
                severity = SecuritySeverity.HIGH,
                remediation = "Update router firmware or regenerate admin TLS certificate with >=2048-bit RSA or ECDSA SHA-256."
            )
        } else if (!trustVerifiedBySystem || isSelfSigned) {
            findings += MultiLayerFinding(
                layer = "TLS / X.509",
                title = "Gateway Uses Self-Signed / Untrusted HTTPS Cert ($negotiatedProtocol)",
                detail = "Certificate is valid cryptographically ($sigAlg, ${keyBits}-bit, Pin=$spkiPin) but not signed by a trusted public CA.",
                verification = FindingVerification.CONFIRMED,
                severity = SecuritySeverity.LOW,
                remediation = "Verify the SHA-256 pin ($spkiPin) matches your router before ignoring browser certificate warnings."
            )
        } else {
            findings += MultiLayerFinding(
                layer = "TLS / X.509",
                title = "Gateway HTTPS Certificate Trusted ($negotiatedProtocol)",
                detail = "Cipher: $negotiatedCipher · Sig: $sigAlg · Key: ${keyBits}-bit.",
                verification = FindingVerification.VERIFIED_SAFE,
                severity = SecuritySeverity.SAFE,
                remediation = "No action needed."
            )
        }

        return "$negotiatedProtocol · $sigAlg (${keyBits}b) · SelfSigned=$isSelfSigned"
    }

    private fun discoverMdnsServices(
        context: Context,
        localIp: String,
        findings: MutableList<MultiLayerFinding>
    ): List<String> {
        if (localIp == "-" || !LocalNetworkDiagnostics.isPrivateIpv4(localIp)) return emptyList()

        val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val lock = wifiManager.createMulticastLock("wifi_scanner_mdns").apply {
            setReferenceCounted(true)
            acquire()
        }
        val discovered = mutableListOf<String>()
        try {
            JmDNS.create(InetAddress.getByName(localIp)).use { jmdns ->
                val types = listOf(
                    "_http._tcp.local.",
                    "_ssh._tcp.local.",
                    "_smb._tcp.local.",
                    "_ipp._tcp.local.",
                    "_rtsp._tcp.local."
                )
                types.forEach { svcType ->
                    val infos = jmdns.list(svcType, 550L)
                    infos.forEach { info ->
                        val host = info.inet4Addresses.firstOrNull()?.hostAddress ?: info.server
                        discovered += "${info.name} (${svcType.removeSuffix(".local.")} @ $host:${info.port})"
                    }
                }
            }
        } catch (err: Throwable) {
            Timber.w(err, "JmDNS discovery failed")
        } finally {
            if (lock.isHeld) lock.release()
        }

        val exposedSmbOrRtsp = discovered.filter {
            it.contains("_smb") || it.contains("_rtsp") || it.contains("_http._tcp")
        }
        if (exposedSmbOrRtsp.isNotEmpty()) {
            findings += MultiLayerFinding(
                layer = "LAN / mDNS",
                title = "Confirmed ${exposedSmbOrRtsp.size} Local Service(s) via mDNS/ZeroConf",
                detail = exposedSmbOrRtsp.take(5).joinToString("; "),
                verification = FindingVerification.CONFIRMED,
                severity = SecuritySeverity.LOW,
                remediation = "Ensure discovered file shares (SMB), cameras (RTSP), and HTTP dashboards require strong authentication."
            )
        }
        return discovered.distinct()
    }

    private suspend fun probeSsdpUpnpResponders(
        isWifiConnected: Boolean,
        findings: MutableList<MultiLayerFinding>
    ): List<String> {
        if (!isWifiConnected) return emptyList()
        val responders = mutableListOf<String>()
        val selector = SelectorManager(Dispatchers.IO)
        try {
            aSocket(selector).udp().bind().use { udpSocket ->
                val searchMsg = (
                    "M-SEARCH * HTTP/1.1\r\n" +
                        "HOST: 239.255.255.250:1900\r\n" +
                        "MAN: \"ssdp:discover\"\r\n" +
                        "MX: 1\r\n" +
                        "ST: upnp:rootdevice\r\n\r\n"
                    ).toByteArray(Charsets.UTF_8)

                val packet = BytePacketBuilder().apply { writeFully(searchMsg) }.build()
                udpSocket.send(Datagram(packet, InetSocketAddress("239.255.255.250", 1900)))

                withTimeoutOrNull(1300L) {
                    repeat(6) {
                        val dg = udpSocket.incoming.receive()
                        val body = dg.packet.readText()
                        val serverLine = body.lineSequence()
                            .firstOrNull { it.startsWith("SERVER:", ignoreCase = true) }
                            ?.substringAfter(":")?.trim()
                        val locationLine = body.lineSequence()
                            .firstOrNull { it.startsWith("LOCATION:", ignoreCase = true) }
                            ?.substringAfter(":")?.trim()
                        val label = listOfNotNull(locationLine, serverLine).joinToString(" | ")
                        if (label.isNotBlank()) responders += label
                    }
                }
            }
        } catch (err: Throwable) {
            Timber.w(err, "Ktor SSDP probe error")
        } finally {
            selector.close()
        }

        val unique = responders.distinct()
        if (unique.any { it.contains("igd", ignoreCase = true) || it.contains("router", ignoreCase = true) || it.contains("1900") }) {
            findings += MultiLayerFinding(
                layer = "UPnP / SSDP",
                title = "Confirmed Active UPnP/SSDP Responder(s) on LAN (${unique.size})",
                detail = unique.take(3).joinToString(" ; "),
                verification = FindingVerification.CONFIRMED,
                severity = SecuritySeverity.MEDIUM,
                remediation = "Disable UPnP on your router if automatic port-forwarding is not strictly required."
            )
        }
        return unique
    }

    private suspend fun confirmOpenPortBanners(
        gatewayIp: String,
        routerPorts: List<LocalPortService>,
        findings: MutableList<MultiLayerFinding>
    ): List<String> {
        if (!LocalNetworkDiagnostics.isPrivateIpv4(gatewayIp) || routerPorts.isEmpty()) return emptyList()
        val banners = mutableListOf<String>()
        val selector = SelectorManager(Dispatchers.IO)
        try {
            routerPorts.take(6).forEach { portInfo ->
                val port = portInfo.port
                if (port in listOf(21, 22, 23, 80, 8080)) {
                    withTimeoutOrNull(1200L) {
                        runCatching {
                            aSocket(selector).tcp().connect(InetSocketAddress(gatewayIp, port)).use { sock ->
                                val readCh = sock.openReadChannel()
                                val writeCh = sock.openWriteChannel(autoFlush = true)
                                if (port == 80 || port == 8080) {
                                    writeCh.writeStringUtf8("HEAD / HTTP/1.0\r\nHost: $gatewayIp\r\n\r\n")
                                }
                                val firstLine = readCh.readUTF8Line(160)?.trim().orEmpty()
                                val secondLine = if (port == 80 || port == 8080) {
                                    buildList {
                                        repeat(5) {
                                            readCh.readUTF8Line(160)?.let { add(it) }
                                        }
                                    }.firstOrNull { it.startsWith("Server:", ignoreCase = true) }?.trim().orEmpty()
                                } else ""
                                val banner = listOf(firstLine, secondLine).filter { it.isNotBlank() }.joinToString(" · ")
                                if (banner.isNotBlank()) {
                                    banners += "Port $port: $banner"
                                    if (port == 21 || port == 23) {
                                        findings += MultiLayerFinding(
                                            layer = "Port Confirmation",
                                            title = "Confirmed Plaintext Service Banner on Port $port",
                                            detail = "Live banner verified via Ktor TCP socket: $banner",
                                            verification = FindingVerification.CONFIRMED,
                                            severity = SecuritySeverity.CRITICAL,
                                            remediation = portInfo.advice
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } finally {
            selector.close()
        }
        return banners
    }
}
