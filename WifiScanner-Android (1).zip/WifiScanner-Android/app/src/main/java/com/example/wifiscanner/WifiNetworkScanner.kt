package com.example.wifiscanner

import android.Manifest
import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.wifi.ScanResult
import android.net.wifi.WifiInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Process
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.io.BufferedReader
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicLong

enum class ScanLogLevel(val code: String, val priority: Int) {
    DEBUG("D", 0),
    INFO("I", 1),
    WARN("W", 2),
    ERROR("E", 3)
}

data class ScanLogEntry(
    val id: Long,
    val timestamp: String,
    val level: ScanLogLevel,
    val tag: String,
    val message: String
)

/**
 * In-app Logcat & Live Scan Diagnostics Ring Buffer.
 * Captures both Timber logs across all security engines and on-demand Android PID logcat output.
 */
object WifiScanLogcatModule {
    private const val MAX_ENTRIES = 160
    private val seq = AtomicLong(0L)
    private val timeFormat = ThreadLocal.withInitial {
        SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    }

    private val _logs = MutableStateFlow<List<ScanLogEntry>>(emptyList())
    val logs: StateFlow<List<ScanLogEntry>> = _logs.asStateFlow()

    @Synchronized
    fun append(level: ScanLogLevel, tag: String, message: String) {
        val ts = timeFormat.get()?.format(Date()) ?: "--:--:--"
        val entry = ScanLogEntry(
            id = seq.incrementAndGet(),
            timestamp = ts,
            level = level,
            tag = tag.ifBlank { "WifiScanner" },
            message = message
        )
        val updated = (_logs.value + entry).takeLast(MAX_ENTRIES)
        _logs.value = updated
    }

    fun clear() {
        _logs.value = emptyList()
    }

    fun createTimberTree(): Timber.Tree {
        return object : Timber.DebugTree() {
            override fun log(priority: Int, tag: String?, message: String, t: Throwable?) {
                super.log(priority, tag, message, t)
                val level = when (priority) {
                    android.util.Log.VERBOSE, android.util.Log.DEBUG -> ScanLogLevel.DEBUG
                    android.util.Log.WARN -> ScanLogLevel.WARN
                    android.util.Log.ERROR, android.util.Log.ASSERT -> ScanLogLevel.ERROR
                    else -> ScanLogLevel.INFO
                }
                val fullMsg = if (t != null) "$message (${t.javaClass.simpleName}: ${t.message})" else message
                append(level, tag ?: "App", fullMsg)
            }
        }
    }

    suspend fun pullOwnProcessLogcat(maxLines: Int = 35): Int = withContext(Dispatchers.IO) {
        val pid = Process.myPid()
        var captured = 0
        runCatching {
            val process = ProcessBuilder(
                "logcat",
                "-d",
                "-v",
                "time",
                "--pid=$pid",
                "-t",
                maxLines.toString()
            ).redirectErrorStream(true).start()

            BufferedReader(InputStreamReader(process.inputStream)).use { reader ->
                val lines = reader.readLines().filter { it.isNotBlank() }.takeLast(maxLines)
                lines.forEach { rawLine ->
                    append(ScanLogLevel.DEBUG, "PID-$pid", rawLine)
                    captured++
                }
            }
            process.destroy()
        }.onFailure { err ->
            append(ScanLogLevel.WARN, "Logcat", "Process logcat unavailable: ${err.message}")
        }
        captured
    }
}

@Composable
fun LiveScanLogcatPanel(modifier: Modifier = Modifier) {
    val entries by WifiScanLogcatModule.logs.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    var minLevel by remember { mutableStateOf(ScanLogLevel.DEBUG) }
    var isPullingPid by remember { mutableStateOf(false) }

    val filtered = remember(entries, minLevel) {
        entries.filter { it.level.priority >= minLevel.priority }.asReversed()
    }

    Card(modifier = modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Live Scan & Logcat (${filtered.size})",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold
                )
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    OutlinedButton(
                        enabled = !isPullingPid,
                        onClick = {
                            scope.launch {
                                isPullingPid = true
                                WifiScanLogcatModule.pullOwnProcessLogcat(30)
                                isPullingPid = false
                            }
                        }
                    ) {
                        Text(if (isPullingPid) "Reading..." else "PID Logcat", fontSize = 11.sp)
                    }
                    TextButton(onClick = { WifiScanLogcatModule.clear() }) {
                        Text("Clear", fontSize = 11.sp)
                    }
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(
                    ScanLogLevel.DEBUG to "All",
                    ScanLogLevel.INFO to "Info+",
                    ScanLogLevel.WARN to "Warn/Err"
                ).forEach { (lvl, label) ->
                    FilterChip(
                        selected = minLevel == lvl,
                        onClick = { minLevel = lvl },
                        label = { Text(label, fontSize = 11.sp) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(190.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF0B1120))
                    .padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                if (filtered.isEmpty()) {
                    item {
                        Text(
                            text = "No logcat entries yet. Trigger a Wi-Fi scan or Deep Audit to observe live events.",
                            color = Color(0xFF94A3B8),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp
                        )
                    }
                } else {
                    items(filtered, key = { it.id }) { entry ->
                        val color = when (entry.level) {
                            ScanLogLevel.DEBUG -> Color(0xFF38BDF8)
                            ScanLogLevel.INFO -> Color(0xFF34D399)
                            ScanLogLevel.WARN -> Color(0xFFFBBF24)
                            ScanLogLevel.ERROR -> Color(0xFFF87171)
                        }
                        Text(
                            text = "${entry.timestamp} ${entry.level.code}/${entry.tag}: ${entry.message}",
                            color = color,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.5.sp,
                            lineHeight = 14.sp
                        )
                    }
                }
            }
        }
    }
}

data class WifiNetworkItem(
    val ssid: String,
    val bssid: String,
    val rssiDbm: Int,
    val signalBars: Int,
    val maxSignalBars: Int,
    val encryptionType: String,
    val frequencyMhz: Int,
    val capabilities: String,
    val securityReport: NetworkSecurityReport
)

class WifiNetworkScanner(private val context: Context) {

    private val wifiManager =
        context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager

    private val locationManager =
        context.applicationContext.getSystemService(Context.LOCATION_SERVICE) as LocationManager

    private var scanCallback: WifiManager.ScanResultsCallback? = null
    private var legacyReceiver: BroadcastReceiver? = null

    fun hasLocationPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun isLocationEnabled(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            locationManager.isLocationEnabled
        } else {
            @Suppress("DEPRECATION")
            locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) ||
                locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
        }
    }

    fun isWifiEnabled(): Boolean = wifiManager.isWifiEnabled

    fun startObserving(onResults: (List<WifiNetworkItem>) -> Unit) {
        stopObserving()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val callback = object : WifiManager.ScanResultsCallback() {
                override fun onScanResultsAvailable() {
                    Timber.tag("WifiScanner").i("ScanResultsCallback fired: reading updated AP list")
                    onResults(readCurrentScanResults())
                }
            }
            scanCallback = callback
            wifiManager.registerScanResultsCallback(context.mainExecutor, callback)
            Timber.tag("WifiScanner").d("Registered API 30+ ScanResultsCallback observer")
        } else {
            val receiver = object : BroadcastReceiver() {
                override fun onReceive(ctx: Context?, intent: Intent?) {
                    if (intent?.action == WifiManager.SCAN_RESULTS_AVAILABLE_ACTION) {
                        val updated = intent.getBooleanExtra(WifiManager.EXTRA_RESULTS_UPDATED, false)
                        Timber.tag("WifiScanner").i("BroadcastReceiver scan update received (fresh=$updated)")
                        onResults(readCurrentScanResults())
                    }
                }
            }
            legacyReceiver = receiver
            context.registerReceiver(
                receiver,
                IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION)
            )
            Timber.tag("WifiScanner").d("Registered legacy SCAN_RESULTS_AVAILABLE_ACTION receiver")
        }

        onResults(readCurrentScanResults())
    }

    fun triggerScan(): Boolean {
        if (!hasLocationPermission()) {
            Timber.tag("WifiScanner").w("Scan blocked: ACCESS_FINE_LOCATION not granted")
            return false
        }
        if (!isWifiEnabled()) {
            Timber.tag("WifiScanner").w("Scan blocked: Wi-Fi adapter is turned OFF")
            return false
        }
        if (!isLocationEnabled()) {
            Timber.tag("WifiScanner").w("Scan blocked: System Location Services disabled")
            return false
        }
        @Suppress("DEPRECATION")
        val accepted = wifiManager.startScan()
        if (accepted) {
            Timber.tag("WifiScanner").i("WifiManager.startScan() accepted by system")
        } else {
            Timber.tag("WifiScanner").w("WifiManager.startScan() throttled (Android 4 scans/2 min limit); using cached results")
        }
        return accepted
    }

    fun stopObserving() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            scanCallback?.let {
                wifiManager.unregisterScanResultsCallback(it)
                Timber.tag("WifiScanner").d("Unregistered ScanResultsCallback")
            }
            scanCallback = null
        }
        legacyReceiver?.let {
            runCatching { context.unregisterReceiver(it) }
            Timber.tag("WifiScanner").d("Unregistered legacy scan receiver")
            legacyReceiver = null
        }
    }

    @SuppressLint("MissingPermission")
    fun readCurrentScanResults(): List<WifiNetworkItem> {
        if (!hasLocationPermission()) return emptyList()

        val rawResults = wifiManager.scanResults ?: return emptyList()
        val mapped = rawResults
            .map { mapScanResult(it) }
            .sortedByDescending { it.rssiDbm }

        val riskyCount = mapped.count { it.securityReport.overallSeverity.priority >= SecuritySeverity.HIGH.priority }
        val strongest = mapped.firstOrNull()?.let { "${it.ssid} (${it.rssiDbm} dBm)" } ?: "none"
        Timber.tag("WifiScanner").i("Parsed ${mapped.size} AP(s) · High/Critical=$riskyCount · Strongest=$strongest")
        return mapped
    }

    private fun mapScanResult(result: ScanResult): WifiNetworkItem {
        val ssid = extractSsid(result)
        val (bars, maxBars) = calculateSignalBars(result.level)
        val encryption = parseEncryption(result)
        val securityReport = WifiSecurityAuditor.audit(result)

        return WifiNetworkItem(
            ssid = ssid.ifBlank { "<Hidden Network>" },
            bssid = result.BSSID ?: "",
            rssiDbm = result.level,
            signalBars = bars,
            maxSignalBars = maxBars,
            encryptionType = encryption,
            frequencyMhz = result.frequency,
            capabilities = result.capabilities ?: "",
            securityReport = securityReport
        )
    }

    private fun extractSsid(result: ScanResult): String {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            result.wifiSsid?.toString()?.removeSurrounding("\"") ?: ""
        } else {
            @Suppress("DEPRECATION")
            result.SSID ?: ""
        }
    }

    private fun calculateSignalBars(rssi: Int): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val maxLevel = wifiManager.maxSignalLevel
            val level = wifiManager.calculateSignalLevel(rssi)
            level to maxLevel
        } else {
            @Suppress("DEPRECATION")
            val level = WifiManager.calculateSignalLevel(rssi, 5)
            level to 4
        }
    }

    private fun parseEncryption(result: ScanResult): String {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val types = result.securityTypes
            if (types.isNotEmpty()) {
                val labels = types.mapNotNull { type ->
                    when (type) {
                        WifiInfo.SECURITY_TYPE_OPEN -> "Open"
                        WifiInfo.SECURITY_TYPE_WEP -> "WEP"
                        WifiInfo.SECURITY_TYPE_PSK -> "WPA/WPA2-PSK"
                        WifiInfo.SECURITY_TYPE_EAP -> "WPA2-Enterprise"
                        WifiInfo.SECURITY_TYPE_SAE -> "WPA3-SAE"
                        WifiInfo.SECURITY_TYPE_OWE -> "OWE (Enhanced Open)"
                        WifiInfo.SECURITY_TYPE_EAP_WPA3_ENTERPRISE,
                        WifiInfo.SECURITY_TYPE_EAP_WPA3_ENTERPRISE_192_BIT -> "WPA3-Enterprise"
                        else -> null
                    }
                }.distinct()
                if (labels.isNotEmpty()) return labels.joinToString(" / ")
            }
        }

        val caps = result.capabilities ?: ""
        return when {
            caps.contains("SAE") -> "WPA3-SAE"
            caps.contains("WPA2") && caps.contains("EAP") -> "WPA2-Enterprise"
            caps.contains("WPA2") || caps.contains("RSN") -> "WPA2-PSK"
            caps.contains("WPA") -> "WPA-PSK"
            caps.contains("WEP") -> "WEP"
            caps.contains("OWE") -> "OWE (Enhanced Open)"
            else -> "Open"
        }
    }
}
