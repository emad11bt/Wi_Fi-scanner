package com.example.wifiscanner

import android.net.wifi.ScanResult
import android.net.wifi.WifiInfo
import android.os.Build
import kotlinx.serialization.Serializable
import java.nio.ByteBuffer
import java.nio.ByteOrder

@Serializable
enum class SecuritySeverity(val label: String, val priority: Int) {
    CRITICAL("Critical Risk", 4),
    HIGH("High Risk", 3),
    MEDIUM("Medium Risk", 2),
    LOW("Baseline", 1),
    SAFE("Strong", 0)
}

data class SecurityFinding(
    val title: String,
    val description: String,
    val remediation: String,
    val severity: SecuritySeverity
)

data class NetworkSecurityReport(
    val overallSeverity: SecuritySeverity,
    val summaryLabel: String,
    val findings: List<SecurityFinding>
)

/**
 * Profiles for safe offline simulation/testing of common WPS posture scenarios
 * without transmitting any active 802.11 / EAPOL frames.
 */
enum class WpsSimulationProfile(val label: String) {
    WPS_DISABLED("WPS Disabled (Recommended)"),
    WPS_PBC_ONLY_LOCKED("WPS Push-Button Only & Setup Locked"),
    WPS_PIN_UNLOCKED_LEGACY("WPS PIN Advertised & Unlocked"),
    WPS_PIXIE_DUST_EXPOSURE_PROFILE("High Pixie-Dust Posture Risk (PIN + Unlocked + Legacy Vendor)")
}

data class WpsBeaconInspection(
    val wpsAdvertised: Boolean,
    val wpsVersion: String?,
    val isConfigured: Boolean?,
    val isSetupLocked: Boolean?,
    val pinMethodSupported: Boolean?,
    val pbcMethodSupported: Boolean?,
    val manufacturer: String?,
    val modelName: String?,
    val pixieDustPostureRisk: String,
    val safePixieDustVerificationGuide: String
)

/**
 * Passive WPS (Wi-Fi Protected Setup) Auditor & Safe Pixie Dust Verification Module.
 *
 * Safe Verification Principles (No active EAPOL M1-M3 injection or PIN cracking):
 * 1. On Android 11+ (API 30+), read public 802.11 Vendor-Specific Information Elements (IE ID = 221)
 *    matching Wi-Fi Alliance WPS OUI (00:50:F2:04) directly from ScanResult.informationElements.
 * 2. Parse WPS TLV attributes safely:
 *    - 0x104A (Version): Detects WPS 1.0 vs 2.0.
 *    - 0x1044 (WPS State): 0x01 = Unconfigured, 0x02 = Configured.
 *    - 0x1057 (AP Setup Locked): 0x00 = Unlocked (PIN retries allowed), 0x01 = Locked.
 *    - 0x1008 (Config Methods): Bitmask checking PIN methods (0x0004 Label, 0x0008 Display,
 *      0x0100 Keypad, 0x2000/0x4000 Virtual/Physical Display) vs Push Button (0x0080).
 *    - 0x1021 / 0x1023 (Manufacturer / Model): Passive hardware/firmware identification.
 * 3. Safe Pixie Dust Verification:
 *    - Pixie Dust exploits weak PRNG nonces (E-S1/E-S2) in unpatched router firmware during EAPOL M1-M3.
 *    - A safe, non-intrusive audit NEVER runs offline PRNG attacks or sends M1-M3 probes; instead, it
 *      checks if WPS PIN is active AND AP Setup is Unlocked (0x1057 == 0x00), flags legacy chipsets/vendors,
 *      and instructs the network owner to verify firmware CVE patches in the router admin UI and disable WPS PIN.
 */
object WpsSecurityInspector {

    private const val IE_VENDOR_SPECIFIC = 221
    private const val TLV_VERSION = 0x104A
    private const val TLV_WPS_STATE = 0x1044
    private const val TLV_AP_SETUP_LOCKED = 0x1057
    private const val TLV_CONFIG_METHODS = 0x1008
    private const val TLV_MANUFACTURER = 0x1021
    private const val TLV_MODEL_NAME = 0x1023

    private const val MASK_PIN_METHODS = 0x0004 or 0x0008 or 0x0100 or 0x2000 or 0x4000
    private const val MASK_PBC_METHODS = 0x0080 or 0x0280 or 0x0480

    private val legacyPrngWatchVendors = listOf(
        "ralink", "mediatek", "broadcom", "realtek", "atheros", "d-link", "tp-link", "netgear", "asus", "zyxel"
    )

    fun inspectBeacon(result: ScanResult, caps: String): WpsBeaconInspection {
        val capsHasWps = caps.contains("WPS", ignoreCase = true)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val elements = runCatching { result.informationElements }.getOrNull().orEmpty()
            for (ie in elements) {
                if (ie.id != IE_VENDOR_SPECIFIC) continue
                val buf = ie.bytes.duplicate().order(ByteOrder.BIG_ENDIAN)
                if (buf.remaining() < 4) continue

                val b0 = buf.get().toInt() and 0xFF
                val b1 = buf.get().toInt() and 0xFF
                val b2 = buf.get().toInt() and 0xFF
                val b3 = buf.get().toInt() and 0xFF

                if (b0 == 0x00 && b1 == 0x50 && b2 == 0xF2 && b3 == 0x04) {
                    return parseWpsTlvBuffer(buf)
                }
            }
        }

        return WpsBeaconInspection(
            wpsAdvertised = capsHasWps,
            wpsVersion = null,
            isConfigured = null,
            isSetupLocked = null,
            pinMethodSupported = if (capsHasWps) true else null,
            pbcMethodSupported = null,
            manufacturer = null,
            modelName = null,
            pixieDustPostureRisk = if (capsHasWps) "Potential (WPS flag present; IE details require API 30+)" else "None (WPS disabled)",
            safePixieDustVerificationGuide = buildSafePixieDustGuide(
                pinEnabled = capsHasWps,
                unlocked = null,
                manufacturer = null,
                modelName = null
            )
        )
    }

    private fun parseWpsTlvBuffer(buf: ByteBuffer): WpsBeaconInspection {
        var version: String? = null
        var configured: Boolean? = null
        var setupLocked: Boolean? = null
        var pinSupported: Boolean? = null
        var pbcSupported: Boolean? = null
        var manufacturer: String? = null
        var modelName: String? = null

        while (buf.remaining() >= 4) {
            val tlvType = buf.short.toInt() and 0xFFFF
            val tlvLen = buf.short.toInt() and 0xFFFF
            if (tlvLen < 0 || tlvLen > buf.remaining()) break

            val value = ByteArray(tlvLen)
            buf.get(value)

            when (tlvType) {
                TLV_VERSION -> if (tlvLen >= 1) {
                    val v = value[0].toInt() and 0xFF
                    version = "${(v shr 4) and 0x0F}.${v and 0x0F}"
                }
                TLV_WPS_STATE -> if (tlvLen >= 1) {
                    configured = (value[0].toInt() and 0xFF) == 0x02
                }
                TLV_AP_SETUP_LOCKED -> if (tlvLen >= 1) {
                    setupLocked = (value[0].toInt() and 0xFF) == 0x01
                }
                TLV_CONFIG_METHODS -> if (tlvLen >= 2) {
                    val mask = ((value[0].toInt() and 0xFF) shl 8) or (value[1].toInt() and 0xFF)
                    pinSupported = (mask and MASK_PIN_METHODS) != 0
                    pbcSupported = (mask and MASK_PBC_METHODS) != 0
                }
                TLV_MANUFACTURER -> manufacturer = value.toString(Charsets.UTF_8).trim().ifBlank { null }
                TLV_MODEL_NAME -> modelName = value.toString(Charsets.UTF_8).trim().ifBlank { null }
            }
        }

        val vendorText = listOfNotNull(manufacturer, modelName).joinToString(" ").lowercase()
        val matchesWatchVendor = legacyPrngWatchVendors.any { vendorText.contains(it) }
        val isUnlocked = setupLocked == false || setupLocked == null
        val pinEnabled = pinSupported == true

        val pixieRisk = when {
            pinEnabled && isUnlocked && matchesWatchVendor ->
                "High Posture Exposure (WPS PIN active, Unlocked, vendor '${manufacturer ?: modelName}' has historical unpatched firmware advisories)"
            pinEnabled && isUnlocked ->
                "Elevated Posture Exposure (WPS PIN active & AP Setup Unlocked)"
            pinEnabled ->
                "Moderate (WPS PIN advertised, but AP Setup Locked)"
            else ->
                "Low (No WPS PIN config method advertised in beacon)"
        }

        return WpsBeaconInspection(
            wpsAdvertised = true,
            wpsVersion = version,
            isConfigured = configured,
            isSetupLocked = setupLocked,
            pinMethodSupported = pinSupported,
            pbcMethodSupported = pbcSupported,
            manufacturer = manufacturer,
            modelName = modelName,
            pixieDustPostureRisk = pixieRisk,
            safePixieDustVerificationGuide = buildSafePixieDustGuide(
                pinEnabled = pinEnabled,
                unlocked = setupLocked != true,
                manufacturer = manufacturer,
                modelName = modelName
            )
        )
    }

    private fun buildSafePixieDustGuide(
        pinEnabled: Boolean,
        unlocked: Boolean?,
        manufacturer: String?,
        modelName: String?
    ): String {
        val hw = listOfNotNull(manufacturer, modelName).joinToString(" ").ifBlank { "router hardware" }
        return if (!pinEnabled) {
            "Safe Check Passed: WPS PIN methods are not advertised. Keep WPS disabled in router settings."
        } else {
            "Safe Verification (No active M1-M3 attack): 1) Confirmed WPS PIN advertised (Unlocked=$unlocked). " +
                "2) Check firmware release notes for $hw regarding WPS weak-PRNG / Pixie Dust patches. " +
                "3) Open Router Admin -> Wireless -> WPS and disable WPS PIN immediately."
        }
    }

    fun evaluateWpsFindings(inspection: WpsBeaconInspection): List<SecurityFinding> {
        if (!inspection.wpsAdvertised) return emptyList()

        val findings = mutableListOf<SecurityFinding>()
        val verLabel = inspection.wpsVersion?.let { "v$it" } ?: "Detected"
        val hwLabel = listOfNotNull(inspection.manufacturer, inspection.modelName).joinToString(" ").ifBlank { "AP" }

        findings += SecurityFinding(
            title = "WPS (Wi-Fi Protected Setup $verLabel) Enabled",
            description = "The access point ($hwLabel) advertises WPS support. Configured=${inspection.isConfigured ?: "Unknown"}, SetupLocked=${inspection.isSetupLocked ?: "Unknown"}.",
            remediation = "Open your router admin panel (Wireless -> WPS) and disable WPS completely, then reboot the router if required.",
            severity = SecuritySeverity.MEDIUM
        )

        if (inspection.isConfigured == false) {
            findings += SecurityFinding(
                title = "WPS Unconfigured State (0x01)",
                description = "Beacon indicates WPS is in unconfigured factory state, allowing external registrar setup on exposed routers.",
                remediation = "Complete initial router setup immediately, set a strong WPA2/WPA3 passphrase, and disable WPS.",
                severity = SecuritySeverity.HIGH
            )
        }

        if (inspection.pinMethodSupported == true) {
            val isUnlocked = inspection.isSetupLocked == false
            val severity = if (isUnlocked) SecuritySeverity.HIGH else SecuritySeverity.MEDIUM
            findings += SecurityFinding(
                title = if (isUnlocked) {
                    "WPS PIN Enabled & Unlocked (Pixie Dust / PIN Exposure)"
                } else {
                    "WPS PIN Config Method Advertised"
                },
                description = "Pixie Dust Posture: ${inspection.pixieDustPostureRisk}. ${inspection.safePixieDustVerificationGuide}",
                remediation = "Disable 'WPS PIN' in router administration (or disable WPS entirely) and verify router firmware is updated against PRNG/Pixie Dust advisories.",
                severity = severity
            )
        }

        return findings
    }
}

object WifiSecurityAuditor {

    fun audit(result: ScanResult): NetworkSecurityReport {
        val findings = mutableListOf<SecurityFinding>()
        val caps = result.capabilities ?: ""

        val isOpen = isOpenNetwork(result, caps)
        val isWep = isWepNetwork(result, caps)
        val isWpa3 = isWpa3Network(result, caps)
        val isWpa2 = isWpa2Network(result, caps)
        val hasTkip = caps.contains("TKIP", ignoreCase = true)
        val hasLegacyWpaOnly = !isWpa2 && !isWpa3 && caps.contains("WPA", ignoreCase = true)
        val isOwe = isOweNetwork(result, caps)

        if (isOpen && !isOwe) {
            findings += SecurityFinding(
                title = "Unencrypted Open Network",
                description = "This network transmits wireless frames without link-layer encryption, allowing passive eavesdropping on unencrypted traffic.",
                remediation = "In router wireless settings, enable WPA3-Personal (SAE) or WPA2-PSK (AES/CCMP) with a strong passphrase. When connecting to public open Wi-Fi, use a trusted VPN and verify HTTPS.",
                severity = SecuritySeverity.CRITICAL
            )
        }

        if (isWep) {
            findings += SecurityFinding(
                title = "Broken WEP Encryption",
                description = "WEP relies on deprecated RC4 key scheduling with known cryptographic flaws that provide virtually no confidentiality.",
                remediation = "Disable WEP immediately in the access point configuration and upgrade to WPA3-SAE or WPA2-PSK using AES (CCMP).",
                severity = SecuritySeverity.CRITICAL
            )
        }

        if (hasLegacyWpaOnly || hasTkip) {
            findings += SecurityFinding(
                title = "Deprecated WPA / TKIP Cipher",
                description = "TKIP and original WPA1 contain well-known cryptographic weaknesses and downgrade risks.",
                remediation = "Switch the router security mode from WPA/WPA2 Mixed (TKIP+AES) to WPA2-PSK [AES/CCMP] only or WPA3-SAE.",
                severity = SecuritySeverity.HIGH
            )
        }

        // Deep passive WPS Information Element (IE 221 / OUI 00:50:F2:04) & Safe Pixie Dust posture check
        val wpsInspection = WpsSecurityInspector.inspectBeacon(result, caps)
        findings += WpsSecurityInspector.evaluateWpsFindings(wpsInspection)

        val hasPmf = caps.contains("MFPC", ignoreCase = true) || caps.contains("MFPR", ignoreCase = true)

        if (!isOpen && !isWep && !hasLegacyWpaOnly && isWpa2 && !isWpa3) {
            if (!hasPmf) {
                findings += SecurityFinding(
                    title = "Protected Management Frames (802.11w) Not Advertised",
                    description = "Management frames (deauthentication/disassociation) are not protected when 802.11w is disabled on WPA2 networks.",
                    remediation = "1. Open router Wireless Security settings. 2. Enable 'PMF' or '802.11w' (Capable or Required). 3. Or upgrade to WPA3-SAE which mandates PMF.",
                    severity = SecuritySeverity.MEDIUM
                )
            }
            findings += SecurityFinding(
                title = "WPA2 Baseline Without WPA3 SAE",
                description = "WPA2-AES is acceptable for compatibility, but lacks WPA3 Simultaneous Authentication of Equals (SAE) forward secrecy.",
                remediation = "1. Use a random passphrase of 16+ characters. 2. Switch security mode to WPA3-SAE (or WPA2/WPA3 Transition if older devices need support).",
                severity = SecuritySeverity.LOW
            )
        }

        if (findings.isEmpty()) {
            val standard = if (isOwe) "Enhanced Open (OWE)" else "WPA3"
            findings += SecurityFinding(
                title = "Modern Wireless Security ($standard)",
                description = "No weak legacy ciphers or open-network misconfigurations were detected in the broadcast beacon.",
                remediation = "Keep router firmware updated, disable remote WAN administration, and change the router admin panel password from the factory default.",
                severity = SecuritySeverity.SAFE
            )
        }

        return finalizeReport(findings)
    }

    /**
     * Safe offline simulator for testing & demonstrating WPS / Pixie Dust posture evaluation rules
     * without sending any packets over the air.
     */
    fun simulateSafeWpsPostureCheck(profile: WpsSimulationProfile): NetworkSecurityReport {
        val simulatedInspection = when (profile) {
            WpsSimulationProfile.WPS_DISABLED -> WpsBeaconInspection(
                wpsAdvertised = false,
                wpsVersion = null,
                isConfigured = true,
                isSetupLocked = true,
                pinMethodSupported = false,
                pbcMethodSupported = false,
                manufacturer = "Simulated Router",
                modelName = "WPA3-Hardened",
                pixieDustPostureRisk = "None (WPS disabled)",
                safePixieDustVerificationGuide = "Safe Check Passed: WPS is disabled."
            )
            WpsSimulationProfile.WPS_PBC_ONLY_LOCKED -> WpsBeaconInspection(
                wpsAdvertised = true,
                wpsVersion = "2.0",
                isConfigured = true,
                isSetupLocked = true,
                pinMethodSupported = false,
                pbcMethodSupported = true,
                manufacturer = "Simulated Router",
                modelName = "PBC-Locked",
                pixieDustPostureRisk = "Low (PIN disabled & AP Setup Locked)",
                safePixieDustVerificationGuide = "Safe Check Passed: No WPS PIN method advertised; still recommended to disable WPS completely."
            )
            WpsSimulationProfile.WPS_PIN_UNLOCKED_LEGACY -> WpsBeaconInspection(
                wpsAdvertised = true,
                wpsVersion = "1.0",
                isConfigured = true,
                isSetupLocked = false,
                pinMethodSupported = true,
                pbcMethodSupported = true,
                manufacturer = "Generic",
                modelName = "WPS1-AP",
                pixieDustPostureRisk = "Elevated Posture Exposure (WPS 1.0 PIN active & AP Setup Unlocked)",
                safePixieDustVerificationGuide = "Verify firmware patches in admin panel and disable WPS PIN immediately."
            )
            WpsSimulationProfile.WPS_PIXIE_DUST_EXPOSURE_PROFILE -> WpsBeaconInspection(
                wpsAdvertised = true,
                wpsVersion = "1.0",
                isConfigured = false,
                isSetupLocked = false,
                pinMethodSupported = true,
                pbcMethodSupported = true,
                manufacturer = "Legacy Ralink/Realtek",
                modelName = "Unpatched-Test-AP",
                pixieDustPostureRisk = "High Posture Exposure (WPS PIN active, Unlocked, legacy chipset profile)",
                safePixieDustVerificationGuide = "Safe Verification: Confirm via IE 221 TLV (0x1008 PIN bit + 0x1057=0 + 0x1021 vendor) without running M1-M3 cracking; patch firmware & disable WPS."
            )
        }

        val findings = WpsSecurityInspector.evaluateWpsFindings(simulatedInspection).toMutableList()
        if (findings.isEmpty()) {
            findings += SecurityFinding(
                title = "Simulation Passed: WPS Disabled",
                description = "Simulated profile '${profile.label}' exposes no WPS PIN or Pixie Dust attack surface.",
                remediation = "Keep WPS disabled in production routers.",
                severity = SecuritySeverity.SAFE
            )
        }
        return finalizeReport(findings)
    }

    private fun finalizeReport(findings: List<SecurityFinding>): NetworkSecurityReport {
        val highest = findings.maxByOrNull { it.severity.priority }?.severity ?: SecuritySeverity.SAFE
        val summary = when (highest) {
            SecuritySeverity.CRITICAL -> "Critical: Immediate hardening needed"
            SecuritySeverity.HIGH -> "High risk cipher or WPS exposure"
            SecuritySeverity.MEDIUM -> "Configuration warning (WPS / PMF)"
            SecuritySeverity.LOW -> "Standard WPA2 baseline"
            SecuritySeverity.SAFE -> "Strong modern security"
        }

        return NetworkSecurityReport(
            overallSeverity = highest,
            summaryLabel = summary,
            findings = findings.sortedBy { it.severity.priority }
        )
    }

    private fun isOpenNetwork(result: ScanResult, caps: String): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (result.securityTypes.contains(WifiInfo.SECURITY_TYPE_OPEN)) return true
            if (result.securityTypes.isNotEmpty()) return false
        }
        return !caps.contains("WEP") &&
            !caps.contains("WPA") &&
            !caps.contains("RSN") &&
            !caps.contains("SAE") &&
            !caps.contains("EAP") &&
            !caps.contains("OWE")
    }

    private fun isWepNetwork(result: ScanResult, caps: String): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (result.securityTypes.contains(WifiInfo.SECURITY_TYPE_WEP)) return true
        }
        return caps.contains("WEP", ignoreCase = true)
    }

    private fun isWpa3Network(result: ScanResult, caps: String): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val types = result.securityTypes
            if (types.contains(WifiInfo.SECURITY_TYPE_SAE) ||
                types.contains(WifiInfo.SECURITY_TYPE_EAP_WPA3_ENTERPRISE) ||
                types.contains(WifiInfo.SECURITY_TYPE_EAP_WPA3_ENTERPRISE_192_BIT)
            ) {
                return true
            }
        }
        return caps.contains("SAE", ignoreCase = true)
    }

    private fun isWpa2Network(result: ScanResult, caps: String): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val types = result.securityTypes
            if (types.contains(WifiInfo.SECURITY_TYPE_PSK) ||
                types.contains(WifiInfo.SECURITY_TYPE_EAP)
            ) {
                return true
            }
        }
        return caps.contains("WPA2", ignoreCase = true) || caps.contains("RSN", ignoreCase = true)
    }

    private fun isOweNetwork(result: ScanResult, caps: String): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (result.securityTypes.contains(WifiInfo.SECURITY_TYPE_OWE)) return true
        }
        return caps.contains("OWE", ignoreCase = true)
    }
}
