package com.example.wifiscanner

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.datetime.Clock
import kotlinx.serialization.json.Json
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.dnsoverhttps.DnsOverHttps
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import timber.log.Timber
import java.net.InetAddress
import java.util.concurrent.TimeUnit

data class TlsAndDohPosture(
    val dohStatus: String,
    val dohTlsVersion: String,
    val dohCipherSuite: String,
    val dohLatencyMs: Long?,
    val gatewayHttpsStatus: String
)

object ModernTlsAndDnsInspector {

    private val jsonFormat = Json { ignoreUnknownKeys = true }

    private val loggingInterceptor = HttpLoggingInterceptor { msg ->
        Timber.tag("OkHttpPosture").d(msg)
    }.apply {
        level = HttpLoggingInterceptor.Level.BASIC
    }

    private val baseClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(3, TimeUnit.SECONDS)
            .readTimeout(3, TimeUnit.SECONDS)
            .addInterceptor(loggingInterceptor)
            .build()
    }

    private val dohResolver: DnsOverHttps by lazy {
        DnsOverHttps.Builder()
            .client(baseClient)
            .url("https://1.1.1.1/dns-query".toHttpUrl())
            .bootstrapDnsHosts(
                InetAddress.getByName("1.1.1.1"),
                InetAddress.getByName("1.0.0.1")
            )
            .build()
    }

    private val dohClient: OkHttpClient by lazy {
        baseClient.newBuilder()
            .dns(dohResolver)
            .build()
    }

    // Retrofit 2.11 + Kotlinx Serialization engine available for structured API/telemetry extensions
    @Suppress("unused")
    val retrofitEngine: Retrofit by lazy {
        Retrofit.Builder()
            .baseUrl("https://cloudflare-dns.com/")
            .client(dohClient)
            .addConverterFactory(jsonFormat.asConverterFactory("application/json".toMediaType()))
            .build()
    }

    suspend fun inspectPosture(gatewayIp: String): TlsAndDohPosture = withContext(Dispatchers.IO) {
        var dohStatus = "Unreachable"
        var dohTls = "-"
        var dohCipher = "-"
        var dohMs: Long? = null

        val startInstant = Clock.System.now()
        runCatching {
            val req = Request.Builder()
                .url("https://1.1.1.1/cdn-cgi/trace")
                .head()
                .build()
            dohClient.newCall(req).execute().use { resp ->
                dohMs = (Clock.System.now() - startInstant).inWholeMilliseconds.coerceAtLeast(1L)
                val handshake = resp.handshake
                dohTls = handshake?.tlsVersion?.javaName ?: "Unknown TLS"
                dohCipher = handshake?.cipherSuite?.javaName ?: "Unknown Cipher"
                dohStatus = "DoH Healthy (HTTP ${resp.code})"
            }
        }.onFailure { err ->
            Timber.w(err, "DoH posture check failed")
            dohStatus = "Offline or blocked (${err.javaClass.simpleName})"
        }

        val gatewayStatus = if (!LocalNetworkDiagnostics.isPrivateIpv4(gatewayIp)) {
            "Not on a private Wi-Fi gateway"
        } else {
            runCatching {
                val gwReq = Request.Builder()
                    .url("https://$gatewayIp/")
                    .head()
                    .build()
                baseClient.newCall(gwReq).execute().use { resp ->
                    val tls = resp.handshake?.tlsVersion?.javaName ?: "TLS"
                    "HTTPS supported (HTTP ${resp.code}, $tls)"
                }
            }.getOrElse { err ->
                val msg = err.message.orEmpty()
                if (msg.contains("CertPath", ignoreCase = true) ||
                    msg.contains("TrustAnchor", ignoreCase = true) ||
                    err is javax.net.ssl.SSLHandshakeException
                ) {
                    "Router uses HTTPS with self-signed cert"
                } else {
                    "Router HTTPS unreachable (may be HTTP-only admin)"
                }
            }
        }

        TlsAndDohPosture(
            dohStatus = dohStatus,
            dohTlsVersion = dohTls,
            dohCipherSuite = dohCipher,
            dohLatencyMs = dohMs,
            gatewayHttpsStatus = gatewayStatus
        )
    }
}
