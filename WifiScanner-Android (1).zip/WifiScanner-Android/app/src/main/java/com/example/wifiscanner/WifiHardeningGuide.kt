package com.example.wifiscanner

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

data class HardeningTip(
    val id: String,
    val title: String,
    val riskClosed: String,
    val actionSteps: String
)

private val defaultHardeningTips = listOf(
    HardeningTip(
        id = "wpa3_aes",
        title = "Use WPA3-SAE or WPA2-PSK (AES Only)",
        riskClosed = "Closes weak WEP, legacy WPA1, and TKIP downgrade weaknesses.",
        actionSteps = "Open your router admin page (192.168.1.1 or 192.168.0.1) -> Wireless Security -> Select WPA3-Personal (SAE) or WPA2-PSK [AES/CCMP] only."
    ),
    HardeningTip(
        id = "disable_wps",
        title = "Disable WPS (Wi-Fi Protected Setup)",
        riskClosed = "Eliminates WPS PIN and push-button attack surfaces.",
        actionSteps = "Go to Wireless Settings -> WPS -> Toggle OFF for both PIN and Push Button Configuration, then save changes."
    ),
    HardeningTip(
        id = "enable_pmf",
        title = "Enable 802.11w Protected Management Frames (PMF)",
        riskClosed = "Protects against forged deauthentication and disassociation management frames.",
        actionSteps = "In Advanced Wireless settings, set PMF / 802.11w to 'Required' (for WPA3) or 'Capable' (for mixed WPA2 devices)."
    ),
    HardeningTip(
        id = "strong_passphrase",
        title = "Set a 16+ Character Unique Wi-Fi Passphrase",
        riskClosed = "Prevents dictionary and offline brute-force guessing of weak passwords.",
        actionSteps = "Use at least 16 random characters (letters, numbers, symbols). Avoid phone numbers, birthdays, or your router brand/SSID."
    ),
    HardeningTip(
        id = "admin_credentials",
        title = "Change Default Router Admin Password",
        riskClosed = "Blocks unauthorized local changes to DNS, port forwarding, and Wi-Fi keys.",
        actionSteps = "Navigate to System / Administration -> Admin Password -> Replace the factory default password with a strong unique password."
    ),
    HardeningTip(
        id = "disable_remote_upnp",
        title = "Disable Remote WAN Admin & Unused UPnP",
        riskClosed = "Prevents external internet access to your router admin interface and automatic port exposure.",
        actionSteps = "Check Security / WAN Settings -> Disable 'Remote Management' and turn off UPnP unless specifically needed by a trusted app."
    ),
    HardeningTip(
        id = "firmware_updates",
        title = "Keep Router Firmware Updated",
        riskClosed = "Patches known driver, chipset, and protocol vulnerabilities in router software.",
        actionSteps = "Open Administration -> Firmware Upgrade -> Check for updates or enable automatic security updates."
    ),
    HardeningTip(
        id = "guest_iot_isolation",
        title = "Isolate IoT & Visitors on a Guest Network",
        riskClosed = "Stops compromised smart-home or visitor devices from reaching computers and NAS storage on your main LAN.",
        actionSteps = "Enable Guest Network with 'Client / AP Isolation' turned ON and 'Allow guests to see local network' turned OFF."
    )
)

@Composable
fun WifiHardeningGuideView(
    completedIds: Set<String>,
    onToggleTip: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val progress = completedIds.size.toFloat() / defaultHardeningTips.size.toFloat()

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "Router & Wi-Fi Hardening Checklist",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Completed ${completedIds.size} of ${defaultHardeningTips.size} security steps (DataStore)",
                    style = MaterialTheme.typography.bodySmall
                )
                Spacer(modifier = Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        defaultHardeningTips.forEach { tip ->
            val checked = completedIds.contains(tip.id)
            val toggle = { onToggleTip(tip.id) }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { toggle() }
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Checkbox(
                        checked = checked,
                        onCheckedChange = { toggle() }
                    )
                    Column(modifier = Modifier.padding(start = 6.dp)) {
                        Text(
                            text = tip.title,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = "Closes: ${tip.riskClosed}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = tip.actionSteps,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }
    }
}
