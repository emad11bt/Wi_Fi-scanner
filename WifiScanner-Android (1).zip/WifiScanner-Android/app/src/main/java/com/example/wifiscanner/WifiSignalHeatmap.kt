package com.example.wifiscanner

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

@Composable
fun WifiSignalHeatmapView(
    networks: List<WifiNetworkItem>,
    selectedNetworkKey: String?,
    onSelectNetwork: (WifiNetworkItem) -> Unit,
    modifier: Modifier = Modifier
) {
    if (networks.isEmpty()) {
        Card(modifier = modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Signal Strength Heatmap",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Scan nearby Wi-Fi networks to plot signal intensity across frequency bands.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
        return
    }

    val strongest = networks.maxByOrNull { it.rssiDbm }

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Signal Heatmap",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    strongest?.let {
                        Text(
                            text = "Peak: ${it.rssiDbm} dBm (${it.ssid})",
                            style = MaterialTheme.typography.bodySmall,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        modifier = Modifier.height(220.dp).padding(end = 6.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("-30 dBm", style = MaterialTheme.typography.labelSmall)
                        Text("-65 dBm", style = MaterialTheme.typography.labelSmall)
                        Text("-95 dBm", style = MaterialTheme.typography.labelSmall)
                    }

                    Canvas(
                        modifier = Modifier
                            .weight(1f)
                            .height(220.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF0F172A))
                    ) {
                        val w = size.width
                        val h = size.height

                        // Horizontal signal reference lines
                        listOf(0.25f, 0.5f, 0.75f).forEach { ratio ->
                            drawLine(
                                color = Color.White.copy(alpha = 0.08f),
                                start = Offset(0f, h * ratio),
                                end = Offset(w, h * ratio),
                                strokeWidth = 1.dp.toPx()
                            )
                        }

                        // Vertical divider between 2.4 GHz (left) and 5/6 GHz (right)
                        drawLine(
                            color = Color.White.copy(alpha = 0.14f),
                            start = Offset(w * 0.5f, 0f),
                            end = Offset(w * 0.5f, h),
                            strokeWidth = 1.dp.toPx()
                        )

                        // Thermal radial gradients for each scanned network
                        networks.forEach { net ->
                            val center = mapNetworkToCanvas(net, w, h)
                            val strength = normalizeRssi(net.rssiDbm)
                            val heatColor = thermalColorForStrength(strength)
                            val radius = (38.dp.toPx() + 56.dp.toPx() * strength)

                            drawCircle(
                                brush = Brush.radialGradient(
                                    colors = listOf(
                                        heatColor.copy(alpha = 0.72f),
                                        heatColor.copy(alpha = 0.28f),
                                        Color.Transparent
                                    ),
                                    center = center,
                                    radius = radius
                                ),
                                radius = radius,
                                center = center
                            )
                        }

                        // Crisp center markers on top of thermal blobs
                        networks.forEach { net ->
                            val center = mapNetworkToCanvas(net, w, h)
                            val itemKey = "${net.bssid}-${net.frequencyMhz}"
                            val isSelected = itemKey == selectedNetworkKey
                            val strength = normalizeRssi(net.rssiDbm)
                            val dotColor = thermalColorForStrength(strength)

                            if (isSelected) {
                                drawCircle(
                                    color = Color.White,
                                    radius = 8.dp.toPx(),
                                    center = center
                                )
                            }
                            drawCircle(
                                color = dotColor,
                                radius = if (isSelected) 5.5.dp.toPx() else 4.dp.toPx(),
                                center = center
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth().padding(start = 52.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("2.4 GHz Band", style = MaterialTheme.typography.labelSmall)
                    Text("5 GHz / 6 GHz Band", style = MaterialTheme.typography.labelSmall)
                }

                Spacer(modifier = Modifier.height(10.dp))
                ThermalLegendBar()
            }
        }

        // Thermal Tile Matrix for quick reading of every scanned network
        Text(
            text = "Network Signal Tiles (Tap to highlight)",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold
        )

        networks.chunked(2).forEach { rowItems ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                rowItems.forEach { net ->
                    val strength = normalizeRssi(net.rssiDbm)
                    val tileColor = thermalColorForStrength(strength)
                    val itemKey = "${net.bssid}-${net.frequencyMhz}"
                    val isSelected = itemKey == selectedNetworkKey

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(tileColor.copy(alpha = if (isSelected) 0.34f else 0.18f))
                            .clickable { onSelectNetwork(net) }
                            .padding(10.dp)
                    ) {
                        Column {
                            Text(
                                text = net.ssid,
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${net.rssiDbm} dBm · ${net.frequencyMhz} MHz",
                                style = MaterialTheme.typography.bodySmall
                            )
                            Text(
                                text = net.encryptionType,
                                style = MaterialTheme.typography.labelSmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
                if (rowItems.size == 1) {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun ThermalLegendBar() {
    Column(modifier = Modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(10.dp)
                .clip(RoundedCornerShape(5.dp))
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(
                            Color(0xFF2563EB),
                            Color(0xFF06B6D4),
                            Color(0xFFEAB308),
                            Color(0xFFF97316),
                            Color(0xFFEF4444)
                        )
                    )
                )
        )
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Weak (-95 dBm)", style = MaterialTheme.typography.labelSmall)
            Text("Moderate (-65 dBm)", style = MaterialTheme.typography.labelSmall)
            Text("Strong (-30 dBm)", style = MaterialTheme.typography.labelSmall)
        }
    }
}

private fun normalizeRssi(rssiDbm: Int): Float {
    return ((rssiDbm - (-95f)) / (-30f - (-95f))).coerceIn(0f, 1f)
}

private fun thermalColorForStrength(strength: Float): Color {
    val cold = Color(0xFF2563EB)
    val cool = Color(0xFF06B6D4)
    val warm = Color(0xFFEAB308)
    val hot = Color(0xFFF97316)
    val peak = Color(0xFFEF4444)

    return when {
        strength < 0.25f -> lerp(cold, cool, strength / 0.25f)
        strength < 0.55f -> lerp(cool, warm, (strength - 0.25f) / 0.30f)
        strength < 0.80f -> lerp(warm, hot, (strength - 0.55f) / 0.25f)
        else -> lerp(hot, peak, (strength - 0.80f) / 0.20f)
    }
}

private fun mapNetworkToCanvas(net: WifiNetworkItem, width: Float, height: Float): Offset {
    val paddingX = width * 0.08f
    val paddingY = height * 0.10f
    val usableW = width - paddingX * 2f
    val usableH = height - paddingY * 2f

    // Map frequency to left half (2.4 GHz) or right half (5/6 GHz)
    val bandRatio = if (net.frequencyMhz < 3000) {
        val chNorm = ((net.frequencyMhz - 2412f) / (2484f - 2412f)).coerceIn(0f, 1f)
        chNorm * 0.45f
    } else {
        val chNorm = ((net.frequencyMhz - 5170f) / (6500f - 5170f)).coerceIn(0f, 1f)
        0.55f + chNorm * 0.45f
    }

    // Small deterministic horizontal spread per BSSID so same-channel APs remain distinct
    val hashOffset = ((net.bssid.hashCode() and 0xFF) / 255f - 0.5f) * 0.06f
    val xNorm = (bandRatio + hashOffset).coerceIn(0f, 1f)

    // Stronger signal closer to the top
    val strength = normalizeRssi(net.rssiDbm)
    val yNorm = 1f - strength

    return Offset(
        x = paddingX + xNorm * usableW,
        y = paddingY + yNorm * usableH
    )
}
