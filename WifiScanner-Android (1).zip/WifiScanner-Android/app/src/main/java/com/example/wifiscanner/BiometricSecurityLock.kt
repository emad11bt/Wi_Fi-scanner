package com.example.wifiscanner

import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

object BiometricSecurityLock {

    private const val ALLOWED_AUTHENTICATORS =
        BiometricManager.Authenticators.BIOMETRIC_STRONG or
            BiometricManager.Authenticators.DEVICE_CREDENTIAL

    fun authenticateVault(
        activity: FragmentActivity,
        onAuthenticated: () -> Unit,
        onStatus: (String) -> Unit
    ) {
        val manager = BiometricManager.from(activity)
        when (manager.canAuthenticate(ALLOWED_AUTHENTICATORS)) {
            BiometricManager.BIOMETRIC_SUCCESS -> {
                val executor = ContextCompat.getMainExecutor(activity)
                val prompt = BiometricPrompt(
                    activity,
                    executor,
                    object : BiometricPrompt.AuthenticationCallback() {
                        override fun onAuthenticationSucceeded(
                            result: BiometricPrompt.AuthenticationResult
                        ) {
                            onAuthenticated()
                        }

                        override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                            onStatus("Authentication canceled: $errString")
                        }

                        override fun onAuthenticationFailed() {
                            onStatus("Biometric not recognized. Try again.")
                        }
                    }
                )

                val promptInfo = BiometricPrompt.PromptInfo.Builder()
                    .setTitle("Unlock Audit History Vault")
                    .setSubtitle("Verify identity to access saved security reports")
                    .setAllowedAuthenticators(ALLOWED_AUTHENTICATORS)
                    .build()

                prompt.authenticate(promptInfo)
            }
            BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> {
                onStatus("No screen lock or biometric enrolled; vault opened.")
                onAuthenticated()
            }
            else -> {
                onStatus("Biometric hardware unavailable; vault opened.")
                onAuthenticated()
            }
        }
    }
}
