package com.example.wifiscanner

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

@Composable
fun SignalStrengthBarsCard(
    networks: List<WifiNetworkItem>,
    modifier: Modifier = Modifier
) {
    Card(modifier = modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = "Signal Strength Distribution (dBm)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Comparative RSSI bar chart across nearby networks (-95 dBm weak to -30 dBm peak).",
                style = MaterialTheme.typography.bodySmall
            )
            Spacer(modifier = Modifier.height(10.dp))

            if (networks.isEmpty()) {
                Text(
                    text = "Scan Wi-Fi networks to populate signal strength bars.",
                    style = MaterialTheme.typography.bodySmall
                )
            } else {
                val topNetworks = networks.sortedByDescending { it.rssiDbm }.take(10)
                topNetworks.forEachIndexed { idx, net ->
                    val ratio = ((net.rssiDbm + 95f) / 65f).coerceIn(0.06f, 1f)
                    val qualityPct = (((net.rssiDbm + 100f) / 70f) * 100f).toInt().coerceIn(0, 100)
                    val barColor = chartSeverityColor(net.securityReport.overallSeverity)

                    if (idx > 0) Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = net.ssid,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "${net.rssiDbm} dBm ($qualityPct%) · ${net.encryptionType}",
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                    Spacer(modifier = Modifier.height(3.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .clip(RoundedCornerShape(5.dp))
                            .background(Color(0xFFE2E8F0))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(ratio)
                                .fillMaxHeight()
                                .clip(RoundedCornerShape(5.dp))
                                .background(barColor)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ChannelCongestionChartCard(
    channelReport: ChannelCongestionReport,
    modifier: Modifier = Modifier
) {
    val ch1 = channelReport.channelLoads24[1] ?: 0
    val ch6 = channelReport.channelLoads24[6] ?: 0
    val ch11 = channelReport.channelLoads24[11] ?: 0
    val entries = listOf(1 to ch1, 6 to ch6, 11 to ch11)
    val maxLoad = entries.maxOf { it.second }.coerceAtLeast(1)

    Card(modifier = modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = "RF Channel & Band Analytics",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "2.4 GHz APs: ${channelReport.band24Count} · 5/6 GHz APs: ${channelReport.band5Count} · Cleanest 2.4 GHz: Ch ${channelReport.recommended24Channel}",
                style = MaterialTheme.typography.bodySmall
            )
            Spacer(modifier = Modifier.height(12.dp))

            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF0F172A))
                    .padding(horizontal = 24.dp, vertical = 14.dp)
            ) {
                val slotW = size.width / entries.size
                val barW = (slotW * 0.42f).coerceAtMost(46.dp.toPx())
                val baselineY = size.height

                // Reference baseline
                drawLine(
                    color = Color.White.copy(alpha = 0.2f),
                    start = Offset(0f, baselineY),
                    end = Offset(size.width, baselineY),
                    strokeWidth = 1.dp.toPx()
                )

                entries.forEachIndexed { index, (channel, load) ->
                    val frac = load.toFloat() / maxLoad.toFloat()
                    val barH = if (load == 0) 4.dp.toPx() else (size.height * 0.86f * frac).coerceAtLeast(8.dp.toPx())
                    val left = index * slotW + (slotW - barW) / 2f
                    val barColor = if (channel == channelReport.recommended24Channel) {
                        Color(0xFF10B981)
                    } else {
                        Color(0xFF38BDF8)
                    }

                    drawRoundRect(
                        color = barColor,
                        topLeft = Offset(left, baselineY - barH),
                        size = Size(barW, barH),
                        cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                entries.forEach { (ch, load) ->
                    val isBest = ch == channelReport.recommended24Channel
                    Text(
                        text = "Ch $ch: $load AP${if (isBest) " (Best)" else ""}",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = if (isBest) FontWeight.Bold else FontWeight.Normal,
                        color = if (isBest) Color(0xFF15803D) else MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

@Composable
fun SeverityBreakdownChartCard(
    findings: List<MonitorFinding>,
    modifier: Modifier = Modifier
) {
    val orderedLevels = listOf(
        SecuritySeverity.SAFE,
        SecuritySeverity.LOW,
        SecuritySeverity.MEDIUM,
        SecuritySeverity.HIGH,
        SecuritySeverity.CRITICAL
    )
    val counts = orderedLevels.associateWith { sev -> findings.count { it.severity == sev } }
    val total = findings.size

    Card(modifier = modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = "Findings Severity Chart (Lowest -> Critical)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Total analyzed findings: $total",
                style = MaterialTheme.typography.bodySmall
            )
            Spacer(modifier = Modifier.height(10.dp))

            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(18.dp)
                    .clip(RoundedCornerShape(9.dp))
                    .background(Color(0xFFE2E8F0))
            ) {
                if (total > 0) {
                    var startX = 0f
                    orderedLevels.forEach { sev ->
                        val count = counts[sev] ?: 0
                        if (count > 0) {
                            val segW = (count.toFloat() / total.toFloat()) * size.width
                            drawRect(
                                color = chartSeverityColor(sev),
                                topLeft = Offset(startX, 0f),
                                size = Size(segW, size.height)
                            )
                            startX += segW
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(8.dp))

            orderedLevels.forEach { sev ->
                val c = counts[sev] ?: 0
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 2.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(chartSeverityColor(sev))
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = sev.label, style = MaterialTheme.typography.labelMedium)
                    }
                    Text(
                        text = "$c",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}

@Composable
fun PingLatencyChartCard(
    pingReport: PingReport,
    jitterMs: Long?,
    modifier: Modifier = Modifier
) {
    val samples = pingReport.samples
    if (samples.isEmpty()) return
    val maxRtt = samples.filter { it.reachable }.maxOfOrNull { it.rttMs }?.coerceAtLeast(5L) ?: 10L

    Card(modifier = modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = "Gateway RTT Latency Chart (ms)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Avg: ${pingReport.avgMs ?: "-"} ms · Max: ${pingReport.maxMs ?: "-"} ms · Jitter: ${jitterMs ?: "-"} ms · Loss: ${pingReport.packetLossPercent}%",
                style = MaterialTheme.typography.bodySmall
            )
            Spacer(modifier = Modifier.height(10.dp))

            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(92.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF0F172A))
                    .padding(horizontal = 14.dp, vertical = 12.dp)
            ) {
                val slotW = size.width / samples.size.coerceAtLeast(1)
                val barW = (slotW * 0.56f).coerceAtMost(24.dp.toPx())
                samples.forEachIndexed { idx, sample ->
                    val left = idx * slotW + (slotW - barW) / 2f
                    if (sample.reachable) {
                        val frac = (sample.rttMs.toFloat() / maxRtt.toFloat()).coerceIn(0.08f, 1f)
                        val barH = size.height * frac
                        val col = when {
                            sample.rttMs <= 15L -> Color(0xFF10B981)
                            sample.rttMs <= 45L -> Color(0xFFF59E0B)
                            else -> Color(0xFFEF4444)
                        }
                        drawRoundRect(
                            color = col,
                            topLeft = Offset(left, size.height - barH),
                            size = Size(barW, barH),
                            cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
                        )
                    } else {
                        drawRoundRect(
                            color = Color(0xFFB91C1C),
                            topLeft = Offset(left, size.height - 6.dp.toPx()),
                            size = Size(barW, 6.dp.toPx()),
                            cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx())
                        )
                    }
                }
            }
        }
    }
}

private fun chartSeverityColor(severity: SecuritySeverity): Color {
    return when (severity) {
        SecuritySeverity.CRITICAL -> Color(0xFFB91C1C)
        SecuritySeverity.HIGH -> Color(0xFFC2410C)
        SecuritySeverity.MEDIUM -> Color(0xFFB45309)
        SecuritySeverity.LOW -> Color(0xFF1D4ED8)
        SecuritySeverity.SAFE -> Color(0xFF15803D)
    }
}
