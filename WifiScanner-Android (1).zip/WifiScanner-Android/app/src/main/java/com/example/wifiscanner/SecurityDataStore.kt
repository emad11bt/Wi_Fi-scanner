package com.example.wifiscanner

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.securityDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "wifi_security_datastore"
)

object SecurityDataStore {
    private val KEY_HARDENING_DONE = stringSetPreferencesKey("hardening_completed_ids")
    private val KEY_LAST_BG_SUMMARY = stringPreferencesKey("last_background_audit_summary")

    fun hardeningProgressFlow(context: Context): Flow<Set<String>> {
        return context.securityDataStore.data.map { prefs ->
            prefs[KEY_HARDENING_DONE] ?: emptySet()
        }
    }

    suspend fun toggleHardeningTip(context: Context, tipId: String) {
        context.securityDataStore.edit { prefs ->
            val current = prefs[KEY_HARDENING_DONE] ?: emptySet()
            prefs[KEY_HARDENING_DONE] = if (current.contains(tipId)) current - tipId else current + tipId
        }
    }

    fun lastBackgroundAuditFlow(context: Context): Flow<String?> {
        return context.securityDataStore.data.map { prefs ->
            prefs[KEY_LAST_BG_SUMMARY]
        }
    }

    suspend fun saveLastBackgroundAudit(context: Context, summary: String) {
        context.securityDataStore.edit { prefs ->
            prefs[KEY_LAST_BG_SUMMARY] = summary
        }
    }
}
