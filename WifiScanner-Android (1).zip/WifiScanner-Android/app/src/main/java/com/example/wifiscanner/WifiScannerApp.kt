package com.example.wifiscanner

import android.app.Application
import org.conscrypt.Conscrypt
import org.koin.android.ext.koin.androidContext
import org.koin.androidx.workmanager.koin.workManagerFactory
import org.koin.core.context.startKoin
import org.xbill.DNS.config.AndroidResolverConfigProvider
import timber.log.Timber
import java.security.Security

class WifiScannerApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Timber.plant(WifiScanLogcatModule.createTimberTree())
        runCatching { AndroidResolverConfigProvider.setContext(this) }
        runCatching { Security.insertProviderAt(Conscrypt.newProvider(), 1) }
        startKoin {
            androidContext(this@WifiScannerApp)
            workManagerFactory()
            modules(appModule)
        }
    }
}
