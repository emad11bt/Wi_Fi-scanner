package com.example.wifiscanner

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import timber.log.Timber
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

class BackgroundSecurityAuditWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val linkInfo = LocalNetworkDiagnostics.readActiveWifiLinkInfo(applicationContext)
        val findings = NetworkSecurityMonitor.evaluateSecurityAndLeaks(
            context = applicationContext,
            linkInfo = linkInfo,
            scannedNetworks = emptyList(),
            routerPorts = emptyList(),
            lanDevices = emptyList()
        )
        val criticalCount = findings.count { it.severity == SecuritySeverity.CRITICAL }
        val highCount = findings.count { it.severity == SecuritySeverity.HIGH }
        val time = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        val summary = "[$time] Link: ${linkInfo.ssid} · Critical: $criticalCount · High: $highCount"
        SecurityDataStore.saveLastBackgroundAudit(applicationContext, summary)
        Timber.i("Background posture audit completed: %s", summary)
        return Result.success()
    }

    companion object {
        private const val WORK_NAME = "periodic_wifi_posture_check"

        fun schedulePeriodicCheck(context: Context) {
            val request = PeriodicWorkRequestBuilder<BackgroundSecurityAuditWorker>(
                15,
                TimeUnit.MINUTES
            ).build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.UPDATE,
                request
            )
        }

        fun cancelPeriodicCheck(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
        }
    }
}
