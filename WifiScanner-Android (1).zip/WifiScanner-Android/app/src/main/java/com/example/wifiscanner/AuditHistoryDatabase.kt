package com.example.wifiscanner

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "audit_history")
data class AuditHistoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timestampIso: String,
    val ssid: String,
    val securityProtocol: String,
    val criticalCount: Int,
    val highCount: Int,
    val mediumCount: Int,
    val reportJson: String
)

@Dao
interface AuditHistoryDao {
    @Query("SELECT * FROM audit_history ORDER BY id DESC")
    fun observeAll(): Flow<List<AuditHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entry: AuditHistoryEntity): Long

    @Query("DELETE FROM audit_history WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM audit_history")
    suspend fun deleteAll()
}

@Database(entities = [AuditHistoryEntity::class], version = 1, exportSchema = false)
abstract class AuditHistoryDatabase : RoomDatabase() {
    abstract fun auditHistoryDao(): AuditHistoryDao

    companion object {
        @Volatile
        private var INSTANCE: AuditHistoryDatabase? = null

        fun getInstance(context: Context): AuditHistoryDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AuditHistoryDatabase::class.java,
                    "wifi_audit_vault.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
