package com.example.wifiscanner

import android.annotation.SuppressLint
import android.content.Context
import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.NetworkCapabilities
import android.net.wifi.ScanResult
import android.net.wifi.WifiInfo
import android.net.wifi.WifiManager
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket

@Serializable
data class ActiveWifiLinkInfo(
    val isWifiConnected: Boolean,
    val ssid: String,
    val localIp: String,
    val gatewayIp: String,
    val dnsServers: List<String>,
    val linkSpeedMbps: Int,
    val frequencyMhz: Int,
    val rssiDbm: Int,
    val wifiStandard: String,
    val securityProtocol: String
)

@Serializable
data class PingSample(
    val sequence: Int,
    val reachable: Boolean,
    val rttMs: Long,
    val method: String
)

@Serializable
data class PingReport(
    val targetHost: String,
    val samples: List<PingSample>,
    val minMs: Long?,
    val avgMs: Long?,
    val maxMs: Long?,
    val packetLossPercent: Int
)

@Serializable
data class LanDevice(
    val ipAddress: String,
    val hostName: String,
    val isGateway: Boolean,
    val isThisDevice: Boolean,
    val latencyMs: Long
)

@Serializable
data class LocalPortService(
    val port: Int,
    val serviceName: String,
    val severity: SecuritySeverity,
    val advice: String
)

private data class KnownPortDef(
    val port: Int,
    val serviceName: String,
    val severity: SecuritySeverity,
    val advice: String
)

object LocalNetworkDiagnostics {

    private val commonLanPorts = listOf(
        KnownPortDef(21, "FTP", SecuritySeverity.CRITICAL, "Unencrypted file transfer. Disable FTP on the router/host and use SFTP instead."),
        KnownPortDef(22, "SSH", SecuritySeverity.LOW, "Secure shell active. Restrict SSH to local LAN and use key-based authentication."),
        KnownPortDef(23, "Telnet", SecuritySeverity.CRITICAL, "Plaintext management protocol. Disable Telnet immediately in router settings."),
        KnownPortDef(53, "DNS", SecuritySeverity.SAFE, "Local DNS resolver (standard on home routers)."),
        KnownPortDef(80, "HTTP", SecuritySeverity.MEDIUM, "Unencrypted web admin/service. Prefer HTTPS (443) for router administration."),
        KnownPortDef(139, "NetBIOS", SecuritySeverity.MEDIUM, "Legacy Windows file-sharing port. Disable if unused on this host."),
        KnownPortDef(443, "HTTPS", SecuritySeverity.SAFE, "Encrypted web service/admin panel."),
        KnownPortDef(445, "SMB", SecuritySeverity.MEDIUM, "Local file sharing. Ensure SMBv1 is disabled and strong account passwords are set."),
        KnownPortDef(554, "RTSP", SecuritySeverity.MEDIUM, "Camera/media stream port. Verify authentication is enabled and isolate on IoT VLAN/Guest Wi-Fi."),
        KnownPortDef(631, "IPP (Printer)", SecuritySeverity.LOW, "Network printing service."),
        KnownPortDef(3389, "RDP", SecuritySeverity.HIGH, "Remote Desktop active. Keep restricted to local LAN only and enforce strong credentials."),
        KnownPortDef(5000, "UPnP / Control", SecuritySeverity.MEDIUM, "Often used by UPnP/router services. Disable UPnP if not needed."),
        KnownPortDef(8080, "HTTP-Alt", SecuritySeverity.MEDIUM, "Alternate unencrypted HTTP service or router admin interface."),
        KnownPortDef(8443, "HTTPS-Alt", SecuritySeverity.SAFE, "Encrypted alternate web admin interface.")
    )

    fun isPrivateIpv4(ip: String): Boolean {
        val parts = ip.trim().split(".")
        if (parts.size != 4) return false
        val octets = parts.mapNotNull { it.toIntOrNull() }
        if (octets.size != 4 || octets.any { it < 0 || it > 255 }) return false
        val a = octets[0]
        val b = octets[1]
        return a == 10 ||
            (a == 172 && b in 16..31) ||
            (a == 192 && b == 168) ||
            a == 127
    }

    @SuppressLint("MissingPermission")
    fun readActiveWifiLinkInfo(context: Context): ActiveWifiLinkInfo {
        val cm = context.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val activeNet = cm.activeNetwork
        val caps = activeNet?.let { cm.getNetworkCapabilities(it) }
        val linkProps: LinkProperties? = activeNet?.let { cm.getLinkProperties(it) }
        val isWifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true

        if (!isWifi) {
            return ActiveWifiLinkInfo(
                isWifiConnected = false,
                ssid = "Not connected to Wi-Fi",
                localIp = "-",
                gatewayIp = "-",
                dnsServers = emptyList(),
                linkSpeedMbps = 0,
                frequencyMhz = 0,
                rssiDbm = 0,
                wifiStandard = "-",
                securityProtocol = "-"
            )
        }

        val wifiInfo: WifiInfo? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            caps?.transportInfo as? WifiInfo
        } else {
            @Suppress("DEPRECATION")
            wm.connectionInfo
        }

        val localIp = linkProps?.linkAddresses
            ?.mapNotNull { it.address as? Inet4Address }
            ?.firstOrNull { !it.isLoopbackAddress }
            ?.hostAddress ?: "-"

        val gatewayIp = linkProps?.routes
            ?.firstOrNull { it.isDefaultRoute && it.gateway is Inet4Address }
            ?.gateway?.hostAddress
            ?: deriveDefaultGatewayFallback(localIp)

        val dnsServers = linkProps?.dnsServers
            ?.mapNotNull { it.hostAddress }
            ?: emptyList()

        val rawSsid = wifiInfo?.ssid?.removeSurrounding("\"") ?: ""
        val ssid = if (rawSsid.isBlank() || rawSsid == "<unknown ssid>") "Connected Wi-Fi" else rawSsid

        val standard = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            when (wifiInfo?.wifiStandard) {
                ScanResult.WIFI_STANDARD_11AX -> "Wi-Fi 6 (802.11ax)"
                ScanResult.WIFI_STANDARD_11AC -> "Wi-Fi 5 (802.11ac)"
                ScanResult.WIFI_STANDARD_11N -> "Wi-Fi 4 (802.11n)"
                ScanResult.WIFI_STANDARD_LEGACY -> "Legacy (802.11a/b/g)"
                else -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                    wifiInfo?.wifiStandard == ScanResult.WIFI_STANDARD_11BE
                ) "Wi-Fi 7 (802.11be)" else "Standard Wi-Fi"
            }
        } else {
            "Standard Wi-Fi"
        }

        val securityProtocol = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            when (wifiInfo?.currentSecurityType) {
                WifiInfo.SECURITY_TYPE_OPEN -> "Open (Unencrypted)"
                WifiInfo.SECURITY_TYPE_WEP -> "WEP (Broken)"
                WifiInfo.SECURITY_TYPE_PSK -> "WPA2-PSK"
                WifiInfo.SECURITY_TYPE_EAP -> "WPA2-Enterprise"
                WifiInfo.SECURITY_TYPE_SAE -> "WPA3-SAE"
                WifiInfo.SECURITY_TYPE_OWE -> "OWE (Enhanced Open)"
                WifiInfo.SECURITY_TYPE_EAP_WPA3_ENTERPRISE,
                WifiInfo.SECURITY_TYPE_EAP_WPA3_ENTERPRISE_192_BIT -> "WPA3-Enterprise"
                else -> "Unknown"
            }
        } else {
            "See Scan Tab for Capabilities"
        }

        return ActiveWifiLinkInfo(
            isWifiConnected = true,
            ssid = ssid,
            localIp = localIp,
            gatewayIp = gatewayIp,
            dnsServers = dnsServers,
            linkSpeedMbps = wifiInfo?.linkSpeed ?: 0,
            frequencyMhz = wifiInfo?.frequency ?: 0,
            rssiDbm = wifiInfo?.rssi ?: 0,
            wifiStandard = standard,
            securityProtocol = securityProtocol
        )
    }

    private fun deriveDefaultGatewayFallback(localIp: String): String {
        val parts = localIp.split(".")
        return if (parts.size == 4) "${parts[0]}.${parts[1]}.${parts[2]}.1" else "-"
    }

    suspend fun pingLocalHost(host: String, count: Int = 4): PingReport = withContext(Dispatchers.IO) {
        if (!isPrivateIpv4(host)) {
            return@withContext PingReport(
                targetHost = host,
                samples = emptyList(),
                minMs = null,
                avgMs = null,
                maxMs = null,
                packetLossPercent = 100
            )
        }

        val samples = mutableListOf<PingSample>()
        val address = InetAddress.getByName(host)

        for (seq in 1..count) {
            val startNs = System.nanoTime()
            var reachable = runCatching { address.isReachable(1200) }.getOrDefault(false)
            var method = "ICMP/Echo"

            if (!reachable) {
                // Fallback TCP connect check on common gateway ports (80/443/53) when ICMP is filtered
                for (probePort in listOf(443, 80, 53)) {
                    val tcpOk = runCatching {
                        Socket().use { s ->
                            s.connect(InetSocketAddress(host, probePort), 800)
                        }
                        true
                    }.getOrDefault(false)
                    if (tcpOk) {
                        reachable = true
                        method = "TCP:$probePort"
                        break
                    }
                }
            }

            val elapsedMs = ((System.nanoTime() - startNs) / 1_000_000L).coerceAtLeast(1L)
            samples += PingSample(
                sequence = seq,
                reachable = reachable,
                rttMs = if (reachable) elapsedMs else 0L,
                method = method
            )
        }

        val successful = samples.filter { it.reachable }.map { it.rttMs }
        val loss = (((count - successful.size).toFloat() / count.toFloat()) * 100f).toInt()

        PingReport(
            targetHost = host,
            samples = samples,
            minMs = successful.minOrNull(),
            avgMs = if (successful.isNotEmpty()) successful.sum() / successful.size else null,
            maxMs = successful.maxOrNull(),
            packetLossPercent = loss
        )
    }

    suspend fun discoverLocalSubnetDevices(
        localIp: String,
        gatewayIp: String,
        onProgress: (Float) -> Unit
    ): List<LanDevice> = withContext(Dispatchers.IO) {
        if (!isPrivateIpv4(localIp)) {
            onProgress(1f)
            return@withContext emptyList()
        }

        val parts = localIp.split(".")
        val prefix = "${parts[0]}.${parts[1]}.${parts[2]}"
        val semaphore = Semaphore(24)
        var completed = 0

        val results = coroutineScope {
            (1..254).map { hostOctet ->
                async {
                    semaphore.withPermit {
                        val candidateIp = "$prefix.$hostOctet"
                        val startNs = System.nanoTime()
                        val addr = InetAddress.getByName(candidateIp)

                        var alive = runCatching { addr.isReachable(350) }.getOrDefault(false)
                        if (!alive) {
                            for (p in listOf(80, 443, 22, 445, 53)) {
                                val open = runCatching {
                                    Socket().use { s ->
                                        s.connect(InetSocketAddress(candidateIp, p), 220)
                                    }
                                    true
                                }.getOrDefault(false)
                                if (open) {
                                    alive = true
                                    break
                                }
                            }
                        }

                        val latency = ((System.nanoTime() - startNs) / 1_000_000L).coerceAtLeast(1L)
                        completed += 1
                        if (completed % 16 == 0 || completed == 254) {
                            onProgress(completed / 254f)
                        }

                        if (alive) {
                            val resolved = runCatching { addr.canonicalHostName }.getOrDefault(candidateIp)
                            LanDevice(
                                ipAddress = candidateIp,
                                hostName = if (resolved == candidateIp) "Local Device" else resolved,
                                isGateway = candidateIp == gatewayIp,
                                isThisDevice = candidateIp == localIp,
                                latencyMs = latency
                            )
                        } else {
                            null
                        }
                    }
                }
            }.awaitAll().filterNotNull()
        }

        results.sortedWith(
            compareByDescending<LanDevice> { it.isGateway }
                .thenByDescending { it.isThisDevice }
                .thenBy { it.ipAddress.substringAfterLast(".").toIntOrNull() ?: 999 }
        )
    }

    suspend fun scanCommonLocalPorts(targetIp: String): List<LocalPortService> = withContext(Dispatchers.IO) {
        if (!isPrivateIpv4(targetIp)) {
            return@withContext emptyList()
        }

        coroutineScope {
            commonLanPorts.map { def ->
                async {
                    val isOpen = runCatching {
                        Socket().use { socket ->
                            socket.connect(InetSocketAddress(targetIp, def.port), 320)
                        }
                        true
                    }.getOrDefault(false)

                    if (isOpen) {
                        LocalPortService(
                            port = def.port,
                            serviceName = def.serviceName,
                            severity = def.severity,
                            advice = def.advice
                        )
                    } else {
                        null
                    }
                }
            }.awaitAll().filterNotNull().sortedBy { it.port }
        }
    }
}
