package com.example.wifiscanner

import android.Manifest
import android.os.Bundle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Lan
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Thermostat
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import kotlinx.collections.immutable.ImmutableList
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import org.koin.androidx.compose.koinViewModel

private enum class AuditFilter(val label: String) {
    ALL("All"),
    ISSUES("Warnings & Risks"),
    STRONG("Strong")
}

private enum class AppRoute(val route: String, val label: String, val icon: ImageVector) {
    SCAN("scan", "Scan", Icons.Rounded.Wifi),
    HEATMAP("heatmap", "Heat", Icons.Rounded.Thermostat),
    DIAGNOSTICS("diagnostics", "Audit/PDF", Icons.Rounded.Lan),
    VAULT("vault", "Vault", Icons.Rounded.History),
    HARDEN("harden", "Harden", Icons.Rounded.Shield)
}

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)

        setContent {
            MaterialTheme {
                WifiScannerScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WifiScannerScreen(auditViewModel: WifiAuditViewModel = koinViewModel()) {
    val context = LocalContext.current
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: AppRoute.SCAN.route

    val hasPermission by auditViewModel.hasPermission.collectAsStateWithLifecycle()
    val networks by auditViewModel.networks.collectAsStateWithLifecycle()
    val statusMessage by auditViewModel.statusMessage.collectAsStateWithLifecycle()
    val lastBackgroundAudit by auditViewModel.lastBackgroundAudit.collectAsStateWithLifecycle()
    val hardeningCompletedIds by auditViewModel.hardeningCompletedIds.collectAsStateWithLifecycle()
    val auditHistory by auditViewModel.auditHistory.collectAsStateWithLifecycle()
    val liveLogcatEntries by WifiScanLogcatModule.logs.collectAsStateWithLifecycle()

    var selectedFilter by remember { mutableStateOf(AuditFilter.ALL) }
    var expandedKey by remember { mutableStateOf<String?>(null) }
    var highlightedHeatmapKey by remember { mutableStateOf<String?>(null) }
    var isVaultUnlocked by remember { mutableStateOf(false) }
    var showLogcatConsole by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        auditViewModel.refreshPermissionState()
        if (results[Manifest.permission.ACCESS_FINE_LOCATION] == true) {
            auditViewModel.startObserving()
            auditViewModel.triggerWifiScan()
        } else {
            auditViewModel.setStatus("Location permission is required by Android to scan Wi-Fi networks.")
        }
    }

    DisposableEffect(hasPermission) {
        if (hasPermission) {
            auditViewModel.startObserving()
        }
        onDispose {
            auditViewModel.stopObserving()
        }
    }

    val filteredNetworks = remember(networks, selectedFilter) {
        when (selectedFilter) {
            AuditFilter.ALL -> networks
            AuditFilter.ISSUES -> networks.filter {
                it.securityReport.overallSeverity.priority >= SecuritySeverity.MEDIUM.priority
            }
            AuditFilter.STRONG -> networks.filter {
                it.securityReport.overallSeverity.priority <= SecuritySeverity.LOW.priority
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Wi-Fi Scanner") })
        },
        bottomBar = {
            NavigationBar {
                AppRoute.entries.forEach { dest ->
                    NavigationBarItem(
                        selected = currentRoute == dest.route,
                        onClick = {
                            navController.navigate(dest.route) {
                                popUpTo(AppRoute.SCAN.route) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(dest.icon, contentDescription = dest.label) },
                        label = {
                            Text(
                                text = if (dest == AppRoute.SCAN) "Scan (${networks.size})" else dest.label,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    )
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (!hasPermission) {
                    Button(onClick = {
                        permissionLauncher.launch(
                            arrayOf(
                                Manifest.permission.ACCESS_FINE_LOCATION,
                                Manifest.permission.ACCESS_COARSE_LOCATION
                            )
                        )
                    }) {
                        Text("Grant Location Permission")
                    }
                } else {
                    Button(onClick = {
                        auditViewModel.triggerWifiScan()
                    }) {
                        Text("Scan Wi-Fi")
                    }
                    Button(onClick = {
                        BackgroundSecurityAuditWorker.schedulePeriodicCheck(context)
                        auditViewModel.setStatus("Scheduled periodic 15-min background posture check via WorkManager.")
                    }) {
                        Text("Auto Audit")
                    }
                }
                OutlinedButton(onClick = { showLogcatConsole = !showLogcatConsole }) {
                    Text(
                        if (showLogcatConsole) {
                            "Hide Logcat"
                        } else {
                            "Logcat (${liveLogcatEntries.size})"
                        }
                    )
                }
            }

            AnimatedVisibility(visible = showLogcatConsole) {
                Column(modifier = Modifier.padding(top = 8.dp)) {
                    LiveScanLogcatPanel()
                }
            }

            lastBackgroundAudit?.let { bg ->
                Spacer(modifier = Modifier.height(6.dp))
                Text(text = "Last Auto Audit: $bg", style = MaterialTheme.typography.labelSmall)
            }

            statusMessage?.let {
                Spacer(modifier = Modifier.height(6.dp))
                Text(text = it, style = MaterialTheme.typography.bodySmall)
            }

            Spacer(modifier = Modifier.height(10.dp))

            NavHost(
                navController = navController,
                startDestination = AppRoute.SCAN.route,
                modifier = Modifier.weight(1f)
            ) {
                composable(AppRoute.SCAN.route) {
                    Column(modifier = Modifier.fillMaxSize()) {
                        if (hasPermission && networks.isNotEmpty()) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                AuditFilter.entries.forEach { filter ->
                                    FilterChip(
                                        selected = selectedFilter == filter,
                                        onClick = { selectedFilter = filter },
                                        label = { Text(filter.label) }
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                        }

                        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(
                                filteredNetworks,
                                key = { "${it.bssid}-${it.frequencyMhz}" }
                            ) { net ->
                                val itemKey = "${net.bssid}-${net.frequencyMhz}"
                                val isExpanded = expandedKey == itemKey
                                val severityColor = severityTextColor(net.securityReport.overallSeverity)

                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            expandedKey = if (isExpanded) null else itemKey
                                        }
                                ) {
                                    Column(modifier = Modifier.padding(14.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = net.ssid,
                                                style = MaterialTheme.typography.titleMedium,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                            Text(
                                                text = net.securityReport.overallSeverity.label,
                                                color = severityColor,
                                                style = MaterialTheme.typography.labelMedium,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "Encryption: ${net.encryptionType}",
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                        Text(
                                            text = "Signal: ${net.rssiDbm} dBm (${net.signalBars}/${net.maxSignalBars} bars) - ${net.frequencyMhz} MHz",
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                        Text(
                                            text = "${net.securityReport.summaryLabel} (Tap for remediation)",
                                            color = severityColor,
                                            style = MaterialTheme.typography.bodySmall
                                        )

                                        AnimatedVisibility(visible = isExpanded) {
                                            Column(modifier = Modifier.padding(top = 10.dp)) {
                                                HorizontalDivider()
                                                Spacer(modifier = Modifier.height(8.dp))
                                                Text(
                                                    text = "BSSID: ${net.bssid}",
                                                    style = MaterialTheme.typography.bodySmall
                                                )
                                                Text(
                                                    text = "Capabilities: ${net.capabilities}",
                                                    style = MaterialTheme.typography.bodySmall
                                                )

                                                net.securityReport.findings.forEach { finding ->
                                                    Spacer(modifier = Modifier.height(10.dp))
                                                    Text(
                                                        text = "[${finding.severity.label}] ${finding.title}",
                                                        color = severityTextColor(finding.severity),
                                                        style = MaterialTheme.typography.labelLarge,
                                                        fontWeight = FontWeight.SemiBold
                                                    )
                                                    Text(
                                                        text = finding.description,
                                                        style = MaterialTheme.typography.bodySmall
                                                    )
                                                    Spacer(modifier = Modifier.height(4.dp))
                                                    Text(
                                                        text = "Fix / Remediation: ${finding.remediation}",
                                                        style = MaterialTheme.typography.bodySmall,
                                                        fontWeight = FontWeight.Medium
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                composable(AppRoute.HEATMAP.route) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        WifiSignalHeatmapView(
                            networks = networks,
                            selectedNetworkKey = highlightedHeatmapKey,
                            onSelectNetwork = { net ->
                                val key = "${net.bssid}-${net.frequencyMhz}"
                                highlightedHeatmapKey = if (highlightedHeatmapKey == key) null else key
                            }
                        )
                        SignalStrengthBarsCard(networks = networks)
                    }
                }

                composable(AppRoute.DIAGNOSTICS.route) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                    ) {
                        NetworkDiagnosticsView(
                            networks = networks,
                            onSaveAuditToVault = { report ->
                                auditViewModel.saveAuditToHistory(report)
                            }
                        )
                    }
                }

                composable(AppRoute.VAULT.route) {
                    AuditVaultView(
                        history = auditHistory,
                        isUnlocked = isVaultUnlocked,
                        onRequestUnlock = {
                            val activity = context as? FragmentActivity
                            if (activity != null) {
                                BiometricSecurityLock.authenticateVault(
                                    activity = activity,
                                    onAuthenticated = { isVaultUnlocked = true },
                                    onStatus = { msg -> auditViewModel.setStatus(msg) }
                                )
                            } else {
                                isVaultUnlocked = true
                            }
                        },
                        onLock = { isVaultUnlocked = false },
                        onDeleteEntry = auditViewModel::deleteHistoryEntry,
                        onClearAll = auditViewModel::clearHistory,
                        onStatus = auditViewModel::setStatus
                    )
                }

                composable(AppRoute.HARDEN.route) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                    ) {
                        WifiHardeningGuideView(
                            completedIds = hardeningCompletedIds,
                            onToggleTip = auditViewModel::toggleHardeningTip
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AuditVaultView(
    history: ImmutableList<AuditHistoryEntity>,
    isUnlocked: Boolean,
    onRequestUnlock: () -> Unit,
    onLock: () -> Unit,
    onDeleteEntry: (Long) -> Unit,
    onClearAll: () -> Unit,
    onStatus: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var pendingPdfReport by remember { mutableStateOf<DeepAuditReport?>(null) }

    val saveVaultPdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        val report = pendingPdfReport ?: return@rememberLauncherForActivityResult
        if (uri != null) {
            scope.launch {
                val res = withContext(Dispatchers.IO) {
                    runCatching {
                        context.contentResolver.openOutputStream(uri)?.use { stream ->
                            PdfReportGenerator.writePdf(
                                report = report,
                                options = ReportCustomizationOptions(),
                                outputStream = stream
                            )
                        } ?: error("Cannot open output stream")
                    }
                }
                res.onSuccess { onStatus("Saved archived PDF report.") }
                    .onFailure { onStatus("Failed saving archived PDF: ${it.message}") }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (!isUnlocked) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Icon(
                        imageVector = Icons.Rounded.Lock,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Biometric Audit History Vault",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Saved Room SQLite audit reports (${history.size}) are protected. Authenticate with Fingerprint, Face, or Device PIN to view or export PDF.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(onClick = onRequestUnlock) {
                        Text("Unlock Vault")
                    }
                }
            }
        } else {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Audit Vault (${history.size} saved)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(onClick = onLock) { Text("Lock") }
                            if (history.isNotEmpty()) {
                                OutlinedButton(onClick = onClearAll) { Text("Clear") }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Persisted locally in Room SQLite with Kotlinx DateTime timestamps.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            if (history.isEmpty()) {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "No archived audits yet. Run Deep Audit in the Audit/PDF tab to store snapshots automatically.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            } else {
                history.forEach { item ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "${item.ssid} (${item.securityProtocol})",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Timestamp: ${item.timestampIso}",
                                style = MaterialTheme.typography.labelSmall
                            )
                            Text(
                                text = "Critical: ${item.criticalCount} · High: ${item.highCount} · Medium: ${item.mediumCount}",
                                style = MaterialTheme.typography.bodySmall
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = {
                                    runCatching {
                                        Json { ignoreUnknownKeys = true }
                                            .decodeFromString<DeepAuditReport>(item.reportJson)
                                    }.onSuccess { decoded ->
                                        pendingPdfReport = decoded
                                        saveVaultPdfLauncher.launch("archived-wifi-audit-${item.id}.pdf")
                                    }.onFailure { err ->
                                        onStatus("Could not decode archived report: ${err.message}")
                                    }
                                }) {
                                    Text("Export PDF")
                                }
                                OutlinedButton(onClick = { onDeleteEntry(item.id) }) {
                                    Text("Delete")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun severityTextColor(severity: SecuritySeverity): Color {
    return when (severity) {
        SecuritySeverity.CRITICAL -> Color(0xFFB91C1C)
        SecuritySeverity.HIGH -> Color(0xFFC2410C)
        SecuritySeverity.MEDIUM -> Color(0xFFB45309)
        SecuritySeverity.LOW -> Color(0xFF1D4ED8)
        SecuritySeverity.SAFE -> Color(0xFF15803D)
    }
}
