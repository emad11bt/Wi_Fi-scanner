package com.example.wifiscanner

import android.content.Context
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

@Serializable
data class ChannelCongestionReport(
    val band24Count: Int,
    val band5Count: Int,
    val recommended24Channel: Int,
    val channelLoads24: Map<Int, Int>,
    val summary: String
)

@Serializable
data class ScannedNetworkSummary(
    val ssid: String,
    val rssiDbm: Int,
    val encryptionType: String,
    val frequencyMhz: Int,
    val overallSeverity: SecuritySeverity
)

@Serializable
data class DeepAuditReport(
    val generatedAt: String,
    val linkInfo: ActiveWifiLinkInfo,
    val channelReport: ChannelCongestionReport,
    val pingReport: PingReport?,
    val jitterMs: Long?,
    val routerPorts: List<LocalPortService>,
    val lanDevices: List<LanDevice>,
    val wirelessFindingsSummary: List<String>,
    val nearbyNetworks: List<ScannedNetworkSummary> = emptyList(),
    val multiLayerSummary: MultiLayerAuditSummary? = null,
    val monitorFindings: List<MonitorFinding>,
    val recommendations: List<String>
)

@Serializable
data class ReportCustomizationOptions(
    val customTitle: String = "Wi-Fi & Local Network Security Audit",
    val inspectorNote: String = "",
    val includeActiveLink: Boolean = true,
    val includeChannelAnalysis: Boolean = true,
    val includeGatewayPing: Boolean = true,
    val includeOpenPorts: Boolean = true,
    val includeLanDevices: Boolean = true,
    val includeNearbyWifi: Boolean = true,
    val includeMultiLayerPosture: Boolean = true,
    val includeMonitorFindings: Boolean = true,
    val includeRecommendations: Boolean = true,
    val minSeverity: SecuritySeverity = SecuritySeverity.SAFE
)

object DeepDiagnosticEngine {

    fun analyzeChannelCongestion(networks: List<WifiNetworkItem>): ChannelCongestionReport {
        val band24 = networks.filter { it.frequencyMhz in 2400..2500 }
        val band5 = networks.filter { it.frequencyMhz >= 4900 }

        val nonOverlapping = listOf(1, 6, 11)
        val loads = mutableMapOf(1 to 0, 6 to 0, 11 to 0)

        band24.forEach { net ->
            val ch = frequencyToChannel(net.frequencyMhz)
            nonOverlapping.forEach { target ->
                if (abs(ch - target) <= 2) {
                    loads[target] = (loads[target] ?: 0) + 1
                }
            }
        }

        val best24 = loads.minByOrNull { it.value }?.key ?: 1
        val bestLoad = loads[best24] ?: 0
        val summary = if (networks.isEmpty()) {
            "No scan results available yet; run a Wi-Fi scan first to compute channel congestion."
        } else {
            "2.4 GHz APs: ${band24.size}, 5/6 GHz APs: ${band5.size}. Cleanest 2.4 GHz channel: Ch $best24 ($bestLoad overlapping APs)."
        }

        return ChannelCongestionReport(
            band24Count = band24.size,
            band5Count = band5.size,
            recommended24Channel = best24,
            channelLoads24 = loads,
            summary = summary
        )
    }

    fun frequencyToChannel(freqMhz: Int): Int {
        return when {
            freqMhz == 2484 -> 14
            freqMhz in 2412..2472 -> (freqMhz - 2407) / 5
            freqMhz in 5170..5835 -> (freqMhz - 5000) / 5
            freqMhz in 5955..7115 -> (freqMhz - 5950) / 5
            else -> 0
        }
    }

    fun buildSnapshotReport(
        context: Context,
        scannedNetworks: List<WifiNetworkItem>,
        linkInfo: ActiveWifiLinkInfo,
        pingReport: PingReport?,
        routerPorts: List<LocalPortService>,
        lanDevices: List<LanDevice>
    ): DeepAuditReport {
        val channelReport = analyzeChannelCongestion(scannedNetworks)
        val rtts = pingReport?.samples?.filter { it.reachable }?.map { it.rttMs }.orEmpty()
        val jitterMs = if (rtts.size >= 2) {
            rtts.zipWithNext { a, b -> abs(a - b) }.sum() / (rtts.size - 1)
        } else {
            null
        }
        val wirelessFindings = scannedNetworks.map { net ->
            "${net.ssid} (${net.rssiDbm} dBm, ${net.encryptionType}): ${net.securityReport.summaryLabel}"
        }
        val nearbySummaries = scannedNetworks
            .sortedByDescending { it.rssiDbm }
            .map { net ->
                ScannedNetworkSummary(
                    ssid = net.ssid,
                    rssiDbm = net.rssiDbm,
                    encryptionType = net.encryptionType,
                    frequencyMhz = net.frequencyMhz,
                    overallSeverity = net.securityReport.overallSeverity
                )
            }
        val monitorFindings = NetworkSecurityMonitor.evaluateSecurityAndLeaks(
            context = context,
            linkInfo = linkInfo,
            scannedNetworks = scannedNetworks,
            routerPorts = routerPorts,
            lanDevices = lanDevices
        )
        val recommendations = buildRecommendations(
            channelReport = channelReport,
            linkInfo = linkInfo,
            routerPorts = routerPorts,
            pingReport = pingReport,
            jitterMs = jitterMs
        )
        val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        return DeepAuditReport(
            generatedAt = timestamp,
            linkInfo = linkInfo,
            channelReport = channelReport,
            pingReport = pingReport,
            jitterMs = jitterMs,
            routerPorts = routerPorts,
            lanDevices = lanDevices,
            wirelessFindingsSummary = wirelessFindings,
            nearbyNetworks = nearbySummaries,
            monitorFindings = monitorFindings,
            recommendations = recommendations
        )
    }

    private fun buildRecommendations(
        channelReport: ChannelCongestionReport,
        linkInfo: ActiveWifiLinkInfo,
        routerPorts: List<LocalPortService>,
        pingReport: PingReport?,
        jitterMs: Long?
    ): List<String> = buildList {
        if (channelReport.band24Count > 0) {
            add("Set 2.4 GHz router channel to Ch ${channelReport.recommended24Channel} (least interference), or prefer 5 GHz for higher throughput.")
        }
        if (linkInfo.securityProtocol.contains("Open", ignoreCase = true) ||
            linkInfo.securityProtocol.contains("WEP", ignoreCase = true)
        ) {
            add("Connected network uses weak/open security; upgrade router to WPA3-SAE or WPA2-PSK (AES/CCMP).")
        }
        routerPorts.filter { it.severity.priority >= SecuritySeverity.MEDIUM.priority }.forEach { port ->
            add("Router Port ${port.port} (${port.serviceName}) is open locally: ${port.advice}")
        }
        if ((pingReport?.packetLossPercent ?: 0) > 0 || (jitterMs ?: 0L) > 25L) {
            add("Elevated gateway latency/jitter detected; check RF channel interference or router CPU load.")
        }
        if (isEmpty()) {
            add("No critical local hygiene issues detected. Keep firmware updated and WPS disabled.")
        }
    }

    suspend fun runDeepDefensiveAudit(
        context: Context,
        scannedNetworks: List<WifiNetworkItem>,
        onStageUpdate: (stageLabel: String, progress: Float) -> Unit
    ): DeepAuditReport {
        onStageUpdate("Stage 1/4: Inspecting active Wi-Fi link & RF channels...", 0.15f)
        val linkInfo = LocalNetworkDiagnostics.readActiveWifiLinkInfo(context)
        val channelReport = analyzeChannelCongestion(scannedNetworks)

        val pingReport: PingReport?
        val jitterMs: Long?
        val routerPorts: List<LocalPortService>
        val lanDevices: List<LanDevice>

        if (linkInfo.isWifiConnected && LocalNetworkDiagnostics.isPrivateIpv4(linkInfo.gatewayIp)) {
            onStageUpdate("Stage 2/4: Measuring gateway latency & jitter (8 probes)...", 0.35f)
            pingReport = LocalNetworkDiagnostics.pingLocalHost(linkInfo.gatewayIp, count = 8)
            val rtts = pingReport.samples.filter { it.reachable }.map { it.rttMs }
            jitterMs = if (rtts.size >= 2) {
                rtts.zipWithNext { a, b -> abs(a - b) }.sum() / (rtts.size - 1)
            } else {
                null
            }

            onStageUpdate("Stage 3/4: Auditing router local management ports...", 0.55f)
            routerPorts = LocalNetworkDiagnostics.scanCommonLocalPorts(linkInfo.gatewayIp)

            onStageUpdate("Stage 4/4: Discovering reachable devices on local subnet...", 0.70f)
            lanDevices = LocalNetworkDiagnostics.discoverLocalSubnetDevices(
                localIp = linkInfo.localIp,
                gatewayIp = linkInfo.gatewayIp,
                onProgress = { sub ->
                    onStageUpdate(
                        "Stage 4/4: Discovering local subnet devices (${(sub * 100).toInt()}%)...",
                        0.70f + sub * 0.28f
                    )
                }
            )
        } else {
            pingReport = null
            jitterMs = null
            routerPorts = emptyList()
            lanDevices = emptyList()
        }

        val wirelessFindings = scannedNetworks.map { net ->
            "${net.ssid} (${net.rssiDbm} dBm, ${net.encryptionType}): ${net.securityReport.summaryLabel}"
        }
        val nearbySummaries = scannedNetworks
            .sortedByDescending { it.rssiDbm }
            .map { net ->
                ScannedNetworkSummary(
                    ssid = net.ssid,
                    rssiDbm = net.rssiDbm,
                    encryptionType = net.encryptionType,
                    frequencyMhz = net.frequencyMhz,
                    overallSeverity = net.securityReport.overallSeverity
                )
            }

        val recommendations = buildRecommendations(
            channelReport = channelReport,
            linkInfo = linkInfo,
            routerPorts = routerPorts,
            pingReport = pingReport,
            jitterMs = jitterMs
        )

        onStageUpdate("Stage 5/5: Multi-layer DNS, mDNS, SSDP, X.509 & banner validation...", 0.90f)
        val multiLayer = MultiLayerNetworkInspector.runMultiLayerInspection(
            context = context,
            linkInfo = linkInfo,
            scannedNetworks = scannedNetworks,
            routerPorts = routerPorts
        )

        val baseMonitorFindings = NetworkSecurityMonitor.evaluateSecurityAndLeaks(
            context = context,
            linkInfo = linkInfo,
            scannedNetworks = scannedNetworks,
            routerPorts = routerPorts,
            lanDevices = lanDevices
        )

        val mergedFindings = (baseMonitorFindings + multiLayer.findings.map { ml ->
            MonitorFinding(
                category = "${ml.layer} [${ml.verification.label}]",
                title = ml.title,
                description = ml.detail,
                remediation = ml.remediation,
                severity = ml.severity
            )
        }).sortedBy { it.severity.priority }

        val mergedRecommendations = (recommendations + multiLayer.findings
            .filter { it.severity.priority >= SecuritySeverity.MEDIUM.priority }
            .map { "[${it.verification.label}] ${it.title}: ${it.remediation}" })
            .distinct()

        onStageUpdate("Audit complete", 1.0f)

        val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        return DeepAuditReport(
            generatedAt = timestamp,
            linkInfo = linkInfo,
            channelReport = channelReport,
            pingReport = pingReport,
            jitterMs = jitterMs,
            routerPorts = routerPorts,
            lanDevices = lanDevices,
            wirelessFindingsSummary = wirelessFindings,
            nearbyNetworks = nearbySummaries,
            multiLayerSummary = multiLayer,
            monitorFindings = mergedFindings,
            recommendations = mergedRecommendations
        )
    }

    fun applyCustomization(
        report: DeepAuditReport,
        options: ReportCustomizationOptions
    ): DeepAuditReport {
        return report.copy(
            pingReport = if (options.includeGatewayPing) report.pingReport else null,
            jitterMs = if (options.includeGatewayPing) report.jitterMs else null,
            routerPorts = if (options.includeOpenPorts) {
                report.routerPorts.filter { it.severity.priority >= options.minSeverity.priority }
            } else {
                emptyList()
            },
            lanDevices = if (options.includeLanDevices) report.lanDevices else emptyList(),
            wirelessFindingsSummary = if (options.includeNearbyWifi) report.wirelessFindingsSummary else emptyList(),
            nearbyNetworks = if (options.includeNearbyWifi) report.nearbyNetworks else emptyList(),
            multiLayerSummary = if (options.includeMultiLayerPosture) report.multiLayerSummary else null,
            monitorFindings = if (options.includeMonitorFindings) {
                report.monitorFindings.filter { it.severity.priority >= options.minSeverity.priority }
            } else {
                emptyList()
            },
            recommendations = if (options.includeRecommendations) report.recommendations else emptyList()
        )
    }

    fun formatReportText(
        report: DeepAuditReport,
        options: ReportCustomizationOptions = ReportCustomizationOptions()
    ): String = buildString {
        val title = options.customTitle.trim().ifBlank { "Wi-Fi & Local Network Defensive Diagnostic Report" }
        val filteredPorts = report.routerPorts.filter { it.severity.priority >= options.minSeverity.priority }
        val filteredFindings = report.monitorFindings.filter { it.severity.priority >= options.minSeverity.priority }

        appendLine("====================================================")
        appendLine(title)
        appendLine("Generated: ${report.generatedAt}")
        if (options.inspectorNote.isNotBlank()) {
            appendLine("Note: ${options.inspectorNote.trim()}")
        }
        appendLine("Minimum Severity Filter: ${options.minSeverity.label}")
        appendLine("====================================================")

        if (options.includeActiveLink) {
            appendLine()
            appendLine("[Active Wi-Fi Connection]")
            appendLine("  SSID: ${report.linkInfo.ssid}")
            appendLine("  Security Protocol: ${report.linkInfo.securityProtocol}")
            appendLine("  Wi-Fi Standard: ${report.linkInfo.wifiStandard}")
            appendLine("  Link Speed: ${report.linkInfo.linkSpeedMbps} Mbps | Freq: ${report.linkInfo.frequencyMhz} MHz | RSSI: ${report.linkInfo.rssiDbm} dBm")
            appendLine("  Local IP: ${report.linkInfo.localIp} | Gateway: ${report.linkInfo.gatewayIp}")
            appendLine("  DNS Servers: ${report.linkInfo.dnsServers.joinToString(", ").ifBlank { "-" }}")
        }

        if (options.includeChannelAnalysis) {
            appendLine()
            appendLine("[RF Channel & Interference Analysis]")
            appendLine("  ${report.channelReport.summary}")
            appendLine("  2.4 GHz Non-Overlapping Loads -> Ch 1: ${report.channelReport.channelLoads24[1]}, Ch 6: ${report.channelReport.channelLoads24[6]}, Ch 11: ${report.channelReport.channelLoads24[11]}")
        }

        if (options.includeGatewayPing) {
            appendLine()
            appendLine("[Gateway Stability (Ping & Jitter)]")
            val p = report.pingReport
            if (p == null) {
                appendLine("  Not available (run Deep Audit on Wi-Fi with a private IPv4 gateway).")
            } else {
                appendLine("  Target: ${p.targetHost} | Packet Loss: ${p.packetLossPercent}%")
                appendLine("  Min: ${p.minMs ?: "-"} ms | Avg: ${p.avgMs ?: "-"} ms | Max: ${p.maxMs ?: "-"} ms | Jitter: ${report.jitterMs ?: "-"} ms")
            }
        }

        if (options.includeOpenPorts) {
            appendLine()
            appendLine("[Local Gateway Open Ports (${report.linkInfo.gatewayIp})]")
            if (filteredPorts.isEmpty()) {
                appendLine("  No matching open management ports.")
            } else {
                filteredPorts.forEach { port ->
                    appendLine("  - Port ${port.port} (${port.serviceName}) [${port.severity.label}]: ${port.advice}")
                }
            }
        }

        if (options.includeLanDevices) {
            appendLine()
            appendLine("[Reachable Devices on Local Subnet (${report.lanDevices.size})]")
            if (report.lanDevices.isEmpty()) {
                appendLine("  None discovered yet.")
            } else {
                report.lanDevices.forEach { d ->
                    val role = when {
                        d.isGateway -> " [Gateway]"
                        d.isThisDevice -> " [This Device]"
                        else -> ""
                    }
                    appendLine("  - ${d.ipAddress}$role | ${d.hostName} | ${d.latencyMs} ms")
                }
            }
        }

        if (options.includeNearbyWifi) {
            appendLine()
            appendLine("[Nearby Wi-Fi Security Summary (${report.wirelessFindingsSummary.size})]")
            if (report.wirelessFindingsSummary.isEmpty()) {
                appendLine("  No scanned Wi-Fi networks included.")
            } else {
                report.wirelessFindingsSummary.forEach { line ->
                    appendLine("  - $line")
                }
            }
        }

        if (options.includeMultiLayerPosture && report.multiLayerSummary != null) {
            val ml = report.multiLayerSummary
            appendLine()
            appendLine("[Multi-Layer Protocol & Vulnerability Confirmation]")
            appendLine("  Subnet CIDR: ${ml.subnetCidr} (${ml.ipScopeLabel})")
            appendLine("  DNS & DNSSEC: ${ml.dnsSecuritySummary}")
            appendLine("  Gateway X.509 / TLS: ${ml.gatewayCertSummary}")
            appendLine("  NTP Clock Drift: ${ml.ntpClockDriftSeconds?.let { "${it}s" } ?: "Not checked / Offline"}")
            appendLine("  mDNS Services Discovered: ${ml.mdnsServicesCount} ${if (ml.mdnsServicesSample.isNotEmpty()) ml.mdnsServicesSample.joinToString(", ") else ""}")
            if (ml.ssdpUpnpResponders.isNotEmpty()) {
                appendLine("  SSDP/UPnP Responders: ${ml.ssdpUpnpResponders.joinToString(" | ")}")
            }
            if (ml.confirmedPortBanners.isNotEmpty()) {
                appendLine("  Confirmed Port Banners: ${ml.confirmedPortBanners.joinToString(" | ")}")
            }
        }

        if (options.includeMonitorFindings) {
            appendLine()
            appendLine("[Findings Sorted Lowest -> Critical (${filteredFindings.size})]")
            if (filteredFindings.isEmpty()) {
                appendLine("  No findings matching the selected severity threshold.")
            } else {
                filteredFindings.forEach { f ->
                    appendLine("  - [${f.severity.label}] (${f.category}) ${f.title}")
                    appendLine("    Fix: ${f.remediation}")
                }
            }
        }

        if (options.includeRecommendations) {
            appendLine()
            appendLine("[Defensive Recommendations]")
            report.recommendations.forEachIndexed { idx, rec ->
                appendLine("  ${idx + 1}. $rec")
            }
        }
    }

    private val prettyJson = Json {
        prettyPrint = true
        encodeDefaults = true
    }

    fun formatReportJson(
        report: DeepAuditReport,
        options: ReportCustomizationOptions = ReportCustomizationOptions()
    ): String {
        return prettyJson.encodeToString(applyCustomization(report, options))
    }
}
