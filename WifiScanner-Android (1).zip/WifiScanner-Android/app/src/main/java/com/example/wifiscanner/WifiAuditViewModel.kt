package com.example.wifiscanner

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.collections.immutable.ImmutableList
import kotlinx.collections.immutable.persistentListOf
import kotlinx.collections.immutable.toImmutableList
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.datetime.Clock
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import timber.log.Timber

class WifiAuditViewModel(
    application: Application,
    private val scanner: WifiNetworkScanner,
    private val auditDao: AuditHistoryDao
) : AndroidViewModel(application) {

    private val _hasPermission = MutableStateFlow(scanner.hasLocationPermission())
    val hasPermission: StateFlow<Boolean> = _hasPermission.asStateFlow()

    private val _networks = MutableStateFlow<ImmutableList<WifiNetworkItem>>(persistentListOf())
    val networks: StateFlow<ImmutableList<WifiNetworkItem>> = _networks.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    val hardeningCompletedIds: StateFlow<Set<String>> =
        SecurityDataStore.hardeningProgressFlow(application)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())

    val lastBackgroundAudit: StateFlow<String?> =
        SecurityDataStore.lastBackgroundAuditFlow(application)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val auditHistory: StateFlow<ImmutableList<AuditHistoryEntity>> =
        auditDao.observeAll()
            .map { it.toImmutableList() }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), persistentListOf())

    fun refreshPermissionState() {
        _hasPermission.value = scanner.hasLocationPermission()
    }

    fun startObserving() {
        if (scanner.hasLocationPermission()) {
            scanner.startObserving { list ->
                _networks.value = list.toImmutableList()
            }
        }
    }

    fun stopObserving() {
        scanner.stopObserving()
    }

    fun triggerWifiScan() {
        when {
            !scanner.hasLocationPermission() ->
                _statusMessage.value = "Location permission is required by Android to scan Wi-Fi networks."
            !scanner.isWifiEnabled() ->
                _statusMessage.value = "Enable Wi-Fi to scan networks."
            !scanner.isLocationEnabled() ->
                _statusMessage.value = "Enable device Location Services to receive scan results."
            else -> {
                val started = scanner.triggerScan()
                _statusMessage.value = if (started) {
                    "Scanning nearby networks..."
                } else {
                    "Scan throttled by Android; showing latest cached results."
                }
            }
        }
    }

    fun setStatus(message: String) {
        _statusMessage.value = message
    }

    fun toggleHardeningTip(id: String) {
        viewModelScope.launch {
            SecurityDataStore.toggleHardeningTip(getApplication(), id)
        }
    }

    fun saveAuditToHistory(report: DeepAuditReport) {
        viewModelScope.launch {
            val crit = report.monitorFindings.count { it.severity == SecuritySeverity.CRITICAL }
            val high = report.monitorFindings.count { it.severity == SecuritySeverity.HIGH }
            val med = report.monitorFindings.count { it.severity == SecuritySeverity.MEDIUM }
            val json = Json.encodeToString(report)
            auditDao.insert(
                AuditHistoryEntity(
                    timestampIso = Clock.System.now().toString(),
                    ssid = report.linkInfo.ssid,
                    securityProtocol = report.linkInfo.securityProtocol,
                    criticalCount = crit,
                    highCount = high,
                    mediumCount = med,
                    reportJson = json
                )
            )
            Timber.i("Saved audit report for SSID=%s to Room Vault", report.linkInfo.ssid)
        }
    }

    fun deleteHistoryEntry(id: Long) {
        viewModelScope.launch {
            auditDao.deleteById(id)
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            auditDao.deleteAll()
        }
    }
}
