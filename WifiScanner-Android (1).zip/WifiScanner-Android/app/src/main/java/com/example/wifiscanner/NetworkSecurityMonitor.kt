package com.example.wifiscanner

import android.content.Context
import android.content.SharedPreferences
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.TrafficStats
import android.os.Build
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys
import kotlinx.serialization.Serializable
import timber.log.Timber

data class LiveTrafficMetrics(
    val rxBytesPerSec: Long,
    val txBytesPerSec: Long,
    val sessionRxKb: Long,
    val sessionTxKb: Long,
    val isPrivateDnsActive: Boolean,
    val privateDnsHost: String?,
    val httpProxyHost: String?,
    val isCaptivePortal: Boolean
)

@Serializable
data class MonitorFinding(
    val category: String,
    val title: String,
    val description: String,
    val remediation: String,
    val severity: SecuritySeverity
)

object NetworkSecurityMonitor {

    private const val PREFS_NAME = "wifi_security_baselines_encrypted"
    private const val FALLBACK_PREFS_NAME = "wifi_security_baselines"
    private const val KEY_TRUSTED_WIFI = "trusted_wifi_entries"
    private const val KEY_TRUSTED_LAN_IPS = "trusted_lan_ips"

    private fun baselinePrefs(context: Context): SharedPreferences {
        return runCatching {
            val masterKeyAlias = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)
            EncryptedSharedPreferences.create(
                PREFS_NAME,
                masterKeyAlias,
                context.applicationContext,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        }.onFailure { err ->
            Timber.w(err, "Falling back to standard SharedPreferences for baseline storage")
        }.getOrElse {
            context.applicationContext.getSharedPreferences(FALLBACK_PREFS_NAME, Context.MODE_PRIVATE)
        }
    }

    fun sampleTrafficAndPosture(
        context: Context,
        prevRxBytes: Long,
        prevTxBytes: Long,
        startRxBytes: Long,
        startTxBytes: Long
    ): Triple<LiveTrafficMetrics, Long, Long> {
        val currentRx = TrafficStats.getTotalRxBytes().coerceAtLeast(0L)
        val currentTx = TrafficStats.getTotalTxBytes().coerceAtLeast(0L)

        val rxSpeed = if (prevRxBytes > 0L && currentRx >= prevRxBytes) currentRx - prevRxBytes else 0L
        val txSpeed = if (prevTxBytes > 0L && currentTx >= prevTxBytes) currentTx - prevTxBytes else 0L

        val cm = context.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNet = cm.activeNetwork
        val linkProps = activeNet?.let { cm.getLinkProperties(it) }
        val netCaps = activeNet?.let { cm.getNetworkCapabilities(it) }

        val privateDnsActive = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            linkProps?.isPrivateDnsActive == true
        } else {
            false
        }
        val privateDnsHost = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            linkProps?.privateDnsServerName
        } else {
            null
        }
        val proxyHost = linkProps?.httpProxy?.let { proxy ->
            val host = proxy.host
            if (!host.isNullOrBlank()) "$host:${proxy.port}" else null
        }
        val isCaptive = netCaps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_CAPTIVE_PORTAL) == true

        val metrics = LiveTrafficMetrics(
            rxBytesPerSec = rxSpeed,
            txBytesPerSec = txSpeed,
            sessionRxKb = ((currentRx - startRxBytes).coerceAtLeast(0L)) / 1024L,
            sessionTxKb = ((currentTx - startTxBytes).coerceAtLeast(0L)) / 1024L,
            isPrivateDnsActive = privateDnsActive,
            privateDnsHost = privateDnsHost,
            httpProxyHost = proxyHost,
            isCaptivePortal = isCaptive
        )
        return Triple(metrics, currentRx, currentTx)
    }

    fun saveTrustedWifiBaseline(context: Context, networks: List<WifiNetworkItem>): Int {
        val prefs = baselinePrefs(context)
        val entries = networks
            .filter { it.ssid != "<Hidden Network>" && it.bssid.isNotBlank() }
            .map { "${it.ssid}|${it.bssid}|${it.securityReport.overallSeverity.priority}" }
            .toSet()
        prefs.edit().putStringSet(KEY_TRUSTED_WIFI, entries).apply()
        return entries.size
    }

    fun saveTrustedLanDevices(context: Context, devices: List<LanDevice>): Int {
        val prefs = baselinePrefs(context)
        val ips = devices.map { it.ipAddress }.toSet()
        prefs.edit().putStringSet(KEY_TRUSTED_LAN_IPS, ips).apply()
        return ips.size
    }

    fun evaluateSecurityAndLeaks(
        context: Context,
        linkInfo: ActiveWifiLinkInfo,
        scannedNetworks: List<WifiNetworkItem>,
        routerPorts: List<LocalPortService>,
        lanDevices: List<LanDevice>
    ): List<MonitorFinding> {
        val findings = mutableListOf<MonitorFinding>()
        val cm = context.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNet = cm.activeNetwork
        val linkProps = activeNet?.let { cm.getLinkProperties(it) }
        val netCaps = activeNet?.let { cm.getNetworkCapabilities(it) }

        // 1. Private DNS (DNS-over-TLS) Leak Check
        if (linkInfo.isWifiConnected) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                if (linkProps?.isPrivateDnsActive != true) {
                    findings += MonitorFinding(
                        category = "Privacy / DNS Leak",
                        title = "Unencrypted DNS Queries (Private DNS Off)",
                        description = "DNS lookups on this Wi-Fi connection are not using DNS-over-TLS, exposing visited domain names to the local network.",
                        remediation = "Open Android Settings -> Network & Internet -> Private DNS -> Set to Automatic or a trusted DoT provider (e.g. dns.google / one.one.one.one).",
                        severity = SecuritySeverity.MEDIUM
                    )
                } else {
                    findings += MonitorFinding(
                        category = "Privacy / DNS",
                        title = "Encrypted Private DNS Active",
                        description = "DNS-over-TLS is active (${linkProps.privateDnsServerName ?: "Automatic"}), protecting domain lookups from local snooping.",
                        remediation = "No action needed; keep Private DNS enabled.",
                        severity = SecuritySeverity.SAFE
                    )
                }
            }

            // 2. HTTP Proxy Interception Check
            val proxy = linkProps?.httpProxy
            if (proxy != null && !proxy.host.isNullOrBlank()) {
                findings += MonitorFinding(
                    category = "Traffic Exposure",
                    title = "Active Wi-Fi HTTP Proxy (${proxy.host}:${proxy.port})",
                    description = "All HTTP/HTTPS app traffic through Android's proxy settings is routed via this local proxy host.",
                    remediation = "If you did not configure this proxy intentionally, open Wi-Fi network details -> Edit -> Proxy -> set to None.",
                    severity = SecuritySeverity.HIGH
                )
            }

            // 3. Captive Portal Check
            if (netCaps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_CAPTIVE_PORTAL) == true) {
                findings += MonitorFinding(
                    category = "Connection State",
                    title = "Captive Portal / Intercepted Network",
                    description = "The network requires sign-in or intercepts HTTP requests before granting internet access.",
                    remediation = "Avoid entering sensitive credentials until authenticated and verified over HTTPS with a VPN.",
                    severity = SecuritySeverity.MEDIUM
                )
            }

            // 4. Connected Wi-Fi Cipher Risk
            if (linkInfo.securityProtocol.contains("Open", ignoreCase = true) ||
                linkInfo.securityProtocol.contains("WEP", ignoreCase = true)
            ) {
                findings += MonitorFinding(
                    category = "Wireless Encryption",
                    title = "Connected to Weak/Unencrypted Wi-Fi (${linkInfo.securityProtocol})",
                    description = "Current Wi-Fi link lacks strong link-layer encryption, creating severe risk of traffic interception.",
                    remediation = "Switch router immediately to WPA3-SAE or WPA2-PSK (AES/CCMP), or use a trusted VPN.",
                    severity = SecuritySeverity.CRITICAL
                )
            }
        }

        // 5. Router Exposed Local Service Ports
        routerPorts.forEach { port ->
            findings += MonitorFinding(
                category = "Local Service Exposure",
                title = "Open Gateway Port ${port.port} (${port.serviceName})",
                description = "Router/Gateway responded on TCP port ${port.port} on the local subnet.",
                remediation = port.advice,
                severity = port.severity
            )
        }

        // 6. Nearby Wi-Fi Configuration Weaknesses
        scannedNetworks.forEach { net ->
            net.securityReport.findings
                .filter { it.severity.priority >= SecuritySeverity.LOW.priority }
                .forEach { f ->
                    findings += MonitorFinding(
                        category = "Wi-Fi Audit (${net.ssid})",
                        title = f.title,
                        description = f.description,
                        remediation = f.remediation,
                        severity = f.severity
                    )
                }
        }

        // 7. Rogue AP / Security Downgrade Baseline Check (Hardware EncryptedSharedPreferences)
        val prefs = baselinePrefs(context)
        val trustedWifi = prefs.getStringSet(KEY_TRUSTED_WIFI, emptySet()).orEmpty()
        if (trustedWifi.isNotEmpty()) {
            val trustedBySsid = trustedWifi.mapNotNull { entry ->
                val parts = entry.split("|")
                if (parts.size == 3) Triple(parts[0], parts[1], parts[2].toIntOrNull() ?: 0) else null
            }.groupBy { it.first }

            scannedNetworks.forEach { net ->
                val matches = trustedBySsid[net.ssid] ?: return@forEach
                val knownBssids = matches.map { it.second }.toSet()
                val bestTrustedPriority = matches.minOf { it.third }

                if (net.securityReport.overallSeverity.priority > bestTrustedPriority &&
                    net.securityReport.overallSeverity.priority >= SecuritySeverity.HIGH.priority
                ) {
                    findings += MonitorFinding(
                        category = "Intrusion Anomaly",
                        title = "Encryption Downgrade Detected on '${net.ssid}'",
                        description = "A trusted SSID appeared with weaker encryption (${net.encryptionType}) than your saved baseline.",
                        remediation = "Do not auto-connect; verify your router configuration and check for unauthorized access points broadcasting your SSID.",
                        severity = SecuritySeverity.CRITICAL
                    )
                } else if (net.bssid.isNotBlank() && !knownBssids.contains(net.bssid)) {
                    findings += MonitorFinding(
                        category = "Intrusion Anomaly",
                        title = "New Unfamiliar BSSID for '${net.ssid}' (${net.bssid})",
                        description = "Your trusted SSID is being broadcast from a MAC/BSSID not in your saved baseline (could be a rogue AP or a new mesh node).",
                        remediation = "Verify whether this BSSID belongs to your mesh extender/router; if unknown, inspect connected APs and change your Wi-Fi passphrase.",
                        severity = SecuritySeverity.HIGH
                    )
                }
            }
        }

        // 8. Unknown LAN Device Intrusion Check
        val trustedLanIps = prefs.getStringSet(KEY_TRUSTED_LAN_IPS, emptySet()).orEmpty()
        if (trustedLanIps.isNotEmpty()) {
            lanDevices
                .filter { !it.isGateway && !it.isThisDevice && !trustedLanIps.contains(it.ipAddress) }
                .forEach { unknown ->
                    findings += MonitorFinding(
                        category = "LAN Intrusion Watch",
                        title = "New Unknown Device on LAN: ${unknown.ipAddress}",
                        description = "Host '${unknown.hostName}' appeared on your local subnet and is not in your saved trusted device baseline.",
                        remediation = "Check your router's DHCP client list; if unrecognized, update your Wi-Fi password and enable guest network isolation.",
                        severity = SecuritySeverity.MEDIUM
                    )
                }
        }

        // Sort strictly from Lowest severity (SAFE / LOW) to Catastrophic (CRITICAL)
        return findings.sortedBy { it.severity.priority }
    }
}
