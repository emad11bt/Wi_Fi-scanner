package com.example.wifiscanner

import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream

object PdfReportGenerator {

    private const val PAGE_WIDTH = 595
    private const val PAGE_HEIGHT = 842
    private const val MARGIN = 40f
    private const val CONTENT_WIDTH = PAGE_WIDTH - MARGIN * 2
    private const val BOTTOM_LIMIT = PAGE_HEIGHT - 52f

    fun writePdf(
        report: DeepAuditReport,
        options: ReportCustomizationOptions,
        outputStream: OutputStream
    ) {
        val document = PdfDocument()
        val state = PdfCursor(document)

        try {
            state.startNewPage()
            drawHeaderBanner(state, report, options)
            drawSummaryBox(state, report, options)
            drawVisualChartsSection(state, report, options)

            if (options.includeActiveLink) {
                state.drawSectionHeader("Active Wi-Fi Connection")
                val link = report.linkInfo
                state.drawKeyValue("SSID", link.ssid)
                state.drawKeyValue("Security Protocol", link.securityProtocol)
                state.drawKeyValue("Wi-Fi Standard", link.wifiStandard)
                state.drawKeyValue(
                    "Link Telemetry",
                    "${link.linkSpeedMbps} Mbps · ${link.frequencyMhz} MHz · ${link.rssiDbm} dBm"
                )
                state.drawKeyValue("Local IP / Gateway", "${link.localIp} / ${link.gatewayIp}")
                state.drawKeyValue(
                    "DNS Servers",
                    link.dnsServers.joinToString(", ").ifBlank { "-" }
                )
                state.y += 8f
            }

            if (options.includeChannelAnalysis) {
                state.drawSectionHeader("RF Channel & Interference Analysis")
                state.drawWrappedText(report.channelReport.summary, size = 10f)
                val loads = report.channelReport.channelLoads24
                state.drawWrappedText(
                    "2.4 GHz Channel Loads -> Ch 1: ${loads[1] ?: 0}, Ch 6: ${loads[6] ?: 0}, Ch 11: ${loads[11] ?: 0}",
                    size = 9.5f,
                    color = Color.parseColor("#475569")
                )
                state.y += 8f
            }

            if (options.includeGatewayPing) {
                state.drawSectionHeader("Gateway Stability (Ping & Jitter)")
                val p = report.pingReport
                if (p == null) {
                    state.drawWrappedText(
                        "Gateway ping data not yet captured. Connect to Wi-Fi and run Deep Audit.",
                        size = 10f,
                        color = Color.parseColor("#475569")
                    )
                } else {
                    state.drawKeyValue("Target Gateway", "${p.targetHost} (Loss: ${p.packetLossPercent}%)")
                    state.drawKeyValue(
                        "Latency / Jitter",
                        "Min ${p.minMs ?: "-"} ms · Avg ${p.avgMs ?: "-"} ms · Max ${p.maxMs ?: "-"} ms · Jitter ${report.jitterMs ?: "-"} ms"
                    )
                }
                state.y += 8f
            }

            if (options.includeOpenPorts) {
                val filteredPorts = report.routerPorts.filter {
                    it.severity.priority >= options.minSeverity.priority
                }
                state.drawSectionHeader("Local Gateway Open Ports (${filteredPorts.size})")
                if (filteredPorts.isEmpty()) {
                    state.drawWrappedText(
                        "No open management ports matched the selected severity filter.",
                        size = 10f,
                        color = Color.parseColor("#475569")
                    )
                } else {
                    filteredPorts.forEach { port ->
                        state.ensureSpace(40f)
                        state.drawWrappedText(
                            "[${port.severity.label}] Port ${port.port} (${port.serviceName})",
                            size = 10f,
                            bold = true,
                            color = severityPdfColor(port.severity)
                        )
                        state.drawWrappedText(
                            "Advice: ${port.advice}",
                            size = 9.5f,
                            color = Color.parseColor("#334155"),
                            indent = 10f
                        )
                        state.y += 4f
                    }
                }
                state.y += 6f
            }

            if (options.includeLanDevices) {
                state.drawSectionHeader("Discovered LAN Devices (${report.lanDevices.size})")
                if (report.lanDevices.isEmpty()) {
                    state.drawWrappedText(
                        "No LAN hosts recorded in this report.",
                        size = 10f,
                        color = Color.parseColor("#475569")
                    )
                } else {
                    report.lanDevices.forEach { dev ->
                        val role = when {
                            dev.isGateway -> " [Gateway]"
                            dev.isThisDevice -> " [This Device]"
                            else -> ""
                        }
                        state.drawWrappedText(
                            "• ${dev.ipAddress}$role — ${dev.hostName} (${dev.latencyMs} ms)",
                            size = 9.5f
                        )
                    }
                }
                state.y += 8f
            }

            if (options.includeNearbyWifi) {
                state.drawSectionHeader("Nearby Wi-Fi Security Audit (${report.wirelessFindingsSummary.size})")
                if (report.wirelessFindingsSummary.isEmpty()) {
                    state.drawWrappedText(
                        "No nearby Wi-Fi networks were captured before exporting.",
                        size = 10f,
                        color = Color.parseColor("#475569")
                    )
                } else {
                    report.wirelessFindingsSummary.forEach { line ->
                        state.drawWrappedText("• $line", size = 9.5f)
                    }
                }
                state.y += 8f
            }

            if (options.includeMultiLayerPosture && report.multiLayerSummary != null) {
                val ml = report.multiLayerSummary
                state.drawSectionHeader("Multi-Layer Protocol & Vulnerability Verification")
                state.drawKeyValue("Subnet & Scope", "${ml.subnetCidr} (${ml.ipScopeLabel})")
                state.drawKeyValue("DNS / DNSSEC Check", ml.dnsSecuritySummary)
                state.drawKeyValue("Gateway TLS / X.509", ml.gatewayCertSummary)
                state.drawKeyValue(
                    "NTP Clock Drift",
                    ml.ntpClockDriftSeconds?.let { "${it} seconds" } ?: "Unavailable (offline)"
                )
                state.drawKeyValue(
                    "mDNS Services (${ml.mdnsServicesCount})",
                    ml.mdnsServicesSample.joinToString(", ").ifBlank { "None advertised" }
                )
                if (ml.ssdpUpnpResponders.isNotEmpty()) {
                    state.drawKeyValue("SSDP/UPnP Responders", ml.ssdpUpnpResponders.joinToString(" · "))
                }
                if (ml.confirmedPortBanners.isNotEmpty()) {
                    state.drawKeyValue("Confirmed Banners", ml.confirmedPortBanners.joinToString(" · "))
                }
                state.y += 8f
            }

            if (options.includeMonitorFindings) {
                val filteredFindings = report.monitorFindings.filter {
                    it.severity.priority >= options.minSeverity.priority
                }
                state.drawSectionHeader("Security & Leak Findings — Lowest to Critical (${filteredFindings.size})")
                if (filteredFindings.isEmpty()) {
                    state.drawWrappedText(
                        "No findings matching severity >= ${options.minSeverity.label}.",
                        size = 10f,
                        color = Color.parseColor("#475569")
                    )
                } else {
                    filteredFindings.forEach { finding ->
                        state.ensureSpace(56f)
                        state.drawWrappedText(
                            "[${finding.severity.label}] (${finding.category}) ${finding.title}",
                            size = 10f,
                            bold = true,
                            color = severityPdfColor(finding.severity)
                        )
                        state.drawWrappedText(
                            finding.description,
                            size = 9.5f,
                            color = Color.parseColor("#1E293B"),
                            indent = 10f
                        )
                        state.drawWrappedText(
                            "Remediation: ${finding.remediation}",
                            size = 9.5f,
                            bold = true,
                            color = Color.parseColor("#0F172A"),
                            indent = 10f
                        )
                        state.y += 6f
                    }
                }
                state.y += 6f
            }

            if (options.includeRecommendations) {
                state.drawSectionHeader("Defensive Recommendations (${report.recommendations.size})")
                report.recommendations.forEachIndexed { index, rec ->
                    state.drawWrappedText("${index + 1}. $rec", size = 10f)
                }
            }

            state.finishCurrentPage()
            document.writeTo(outputStream)
        } finally {
            document.close()
        }
    }

    fun createShareablePdfUri(
        context: Context,
        report: DeepAuditReport,
        options: ReportCustomizationOptions
    ): Uri {
        val reportsDir = File(context.cacheDir, "reports").apply { mkdirs() }
        val safeTimestamp = report.generatedAt.replace(":", "-").replace(" ", "_")
        val outFile = File(reportsDir, "wifi-audit-$safeTimestamp.pdf")
        FileOutputStream(outFile).use { stream ->
            writePdf(report, options, stream)
        }
        return FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            outFile
        )
    }

    private fun drawHeaderBanner(
        state: PdfCursor,
        report: DeepAuditReport,
        options: ReportCustomizationOptions
    ) {
        val title = options.customTitle.trim().ifBlank { "Wi-Fi & Local Network Security Audit" }
        val hasNote = options.inspectorNote.isNotBlank()
        val bannerHeight = if (hasNote) 86f else 70f

        val bgPaint = Paint().apply { color = Color.parseColor("#0F172A") }
        state.canvas.drawRoundRect(
            RectF(MARGIN, state.y, PAGE_WIDTH - MARGIN, state.y + bannerHeight),
            10f,
            10f,
            bgPaint
        )

        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 15f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#CBD5E1")
            textSize = 9.5f
        }

        state.canvas.drawText(
            title.take(64),
            MARGIN + 16f,
            state.y + 26f,
            titlePaint
        )
        state.canvas.drawText(
            "Generated: ${report.generatedAt} · Min Severity: ${options.minSeverity.label}",
            MARGIN + 16f,
            state.y + 46f,
            subPaint
        )
        if (hasNote) {
            state.canvas.drawText(
                "Note: ${options.inspectorNote.trim().take(80)}",
                MARGIN + 16f,
                state.y + 64f,
                subPaint
            )
        }

        state.y += bannerHeight + 14f
    }

    private fun drawSummaryBox(
        state: PdfCursor,
        report: DeepAuditReport,
        options: ReportCustomizationOptions
    ) {
        val filtered = report.monitorFindings.filter {
            it.severity.priority >= options.minSeverity.priority
        }
        val crit = filtered.count { it.severity == SecuritySeverity.CRITICAL }
        val high = filtered.count { it.severity == SecuritySeverity.HIGH }
        val med = filtered.count { it.severity == SecuritySeverity.MEDIUM }
        val low = filtered.count { it.severity == SecuritySeverity.LOW }
        val safe = filtered.count { it.severity == SecuritySeverity.SAFE }

        val boxPaint = Paint().apply { color = Color.parseColor("#F1F5F9") }
        val borderPaint = Paint().apply {
            color = Color.parseColor("#CBD5E1")
            style = Paint.Style.STROKE
            strokeWidth = 1f
        }
        val rect = RectF(MARGIN, state.y, PAGE_WIDTH - MARGIN, state.y + 46f)
        state.canvas.drawRoundRect(rect, 8f, 8f, boxPaint)
        state.canvas.drawRoundRect(rect, 8f, 8f, borderPaint)

        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#0F172A")
            textSize = 10f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        state.canvas.drawText(
            "SSID: ${report.linkInfo.ssid} (${report.linkInfo.securityProtocol}) · Total Findings: ${filtered.size}",
            MARGIN + 12f,
            state.y + 18f,
            textPaint
        )

        val countsPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#334155")
            textSize = 9.5f
        }
        state.canvas.drawText(
            "Critical: $crit   |   High: $high   |   Medium: $med   |   Baseline: $low   |   Strong: $safe",
            MARGIN + 12f,
            state.y + 35f,
            countsPaint
        )

        state.y += 60f
    }

    private fun drawVisualChartsSection(
        state: PdfCursor,
        report: DeepAuditReport,
        options: ReportCustomizationOptions
    ) {
        state.drawSectionHeader("Visual Signal & Security Analytics")

        // 1. Severity Distribution Stacked Bar
        val filtered = report.monitorFindings.filter {
            it.severity.priority >= options.minSeverity.priority
        }
        val ordered = listOf(
            SecuritySeverity.SAFE,
            SecuritySeverity.LOW,
            SecuritySeverity.MEDIUM,
            SecuritySeverity.HIGH,
            SecuritySeverity.CRITICAL
        )
        val totalFindings = filtered.size
        state.ensureSpace(46f)
        val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#334155")
            textSize = 9.2f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        state.canvas.drawText("Findings Severity Distribution ($totalFindings total)", MARGIN, state.y + 10f, labelPaint)
        state.y += 15f

        val barBgPaint = Paint().apply { color = Color.parseColor("#E2E8F0") }
        val barRect = RectF(MARGIN, state.y, PAGE_WIDTH - MARGIN, state.y + 14f)
        state.canvas.drawRoundRect(barRect, 5f, 5f, barBgPaint)

        if (totalFindings > 0) {
            var curX = MARGIN
            ordered.forEach { sev ->
                val cnt = filtered.count { it.severity == sev }
                if (cnt > 0) {
                    val segW = (cnt.toFloat() / totalFindings.toFloat()) * CONTENT_WIDTH
                    val segPaint = Paint().apply { color = severityPdfColor(sev) }
                    state.canvas.drawRect(curX, state.y, curX + segW, state.y + 14f, segPaint)
                    curX += segW
                }
            }
        }
        state.y += 22f

        // 2. 2.4 GHz Channel Congestion Column Chart
        if (options.includeChannelAnalysis) {
            state.ensureSpace(104f)
            state.canvas.drawText(
                "2.4 GHz Channel Congestion (Recommended: Ch ${report.channelReport.recommended24Channel})",
                MARGIN,
                state.y + 10f,
                labelPaint
            )
            state.y += 16f

            val chEntries = listOf(
                1 to (report.channelReport.channelLoads24[1] ?: 0),
                6 to (report.channelReport.channelLoads24[6] ?: 0),
                11 to (report.channelReport.channelLoads24[11] ?: 0)
            )
            val maxLoad = chEntries.maxOf { it.second }.coerceAtLeast(1)
            val chartTop = state.y
            val chartHeight = 56f
            val chartBottom = chartTop + chartHeight
            val chartBg = Paint().apply { color = Color.parseColor("#F8FAFC") }
            val chartBorder = Paint().apply {
                color = Color.parseColor("#CBD5E1")
                style = Paint.Style.STROKE
                strokeWidth = 1f
            }
            val chartRect = RectF(MARGIN, chartTop, PAGE_WIDTH - MARGIN, chartBottom + 18f)
            state.canvas.drawRoundRect(chartRect, 6f, 6f, chartBg)
            state.canvas.drawRoundRect(chartRect, 6f, 6f, chartBorder)

            val slotW = CONTENT_WIDTH / chEntries.size
            val colW = 44f
            val axisPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#334155")
                textSize = 8.5f
                textAlign = Paint.Align.CENTER
            }
            chEntries.forEachIndexed { idx, (ch, load) ->
                val centerX = MARGIN + idx * slotW + slotW / 2f
                val frac = load.toFloat() / maxLoad.toFloat()
                val colH = if (load == 0) 3f else (42f * frac).coerceAtLeast(6f)
                val isBest = ch == report.channelReport.recommended24Channel
                val colPaint = Paint().apply {
                    color = Color.parseColor(if (isBest) "#15803D" else "#0284C7")
                }
                val r = RectF(centerX - colW / 2f, chartBottom - colH, centerX + colW / 2f, chartBottom)
                state.canvas.drawRoundRect(r, 4f, 4f, colPaint)
                state.canvas.drawText("$load AP", centerX, chartBottom - colH - 3f, axisPaint)
                state.canvas.drawText(
                    if (isBest) "Ch $ch (Best)" else "Ch $ch",
                    centerX,
                    chartBottom + 12f,
                    axisPaint
                )
            }
            state.y = chartBottom + 28f
        }

        // 3. Top Nearby Wi-Fi Signal Strength Bars (dBm)
        if (options.includeNearbyWifi && report.nearbyNetworks.isNotEmpty()) {
            val topNets = report.nearbyNetworks.sortedByDescending { it.rssiDbm }.take(8)
            state.ensureSpace(26f + topNets.size * 18f)
            state.canvas.drawText(
                "Nearby Wi-Fi Signal Strength (dBm)",
                MARGIN,
                state.y + 10f,
                labelPaint
            )
            state.y += 16f

            val ssidPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#0F172A")
                textSize = 8.5f
            }
            val rssiPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#475569")
                textSize = 8.2f
            }
            val labelW = 145f
            val valueW = 95f
            val maxBarW = CONTENT_WIDTH - labelW - valueW - 12f

            topNets.forEach { net ->
                state.ensureSpace(20f)
                state.canvas.drawText(net.ssid.take(24), MARGIN, state.y + 9f, ssidPaint)

                val trackX = MARGIN + labelW
                val trackRect = RectF(trackX, state.y + 2f, trackX + maxBarW, state.y + 11f)
                state.canvas.drawRoundRect(trackRect, 4f, 4f, barBgPaint)

                val norm = ((net.rssiDbm + 95f) / 65f).coerceIn(0.06f, 1f)
                val fillPaint = Paint().apply { color = severityPdfColor(net.overallSeverity) }
                val fillRect = RectF(trackX, state.y + 2f, trackX + maxBarW * norm, state.y + 11f)
                state.canvas.drawRoundRect(fillRect, 4f, 4f, fillPaint)

                state.canvas.drawText(
                    "${net.rssiDbm} dBm · ${net.encryptionType.take(10)}",
                    trackX + maxBarW + 8f,
                    state.y + 9f,
                    rssiPaint
                )
                state.y += 17f
            }
            state.y += 6f
        }

        // 4. Gateway Ping RTT Latency Bars (ms)
        val ping = report.pingReport
        if (options.includeGatewayPing && ping != null && ping.samples.isNotEmpty()) {
            state.ensureSpace(90f)
            state.canvas.drawText(
                "Gateway Ping RTT Probes (${ping.targetHost} · Avg ${ping.avgMs ?: "-"} ms · Jitter ${report.jitterMs ?: "-"} ms)",
                MARGIN,
                state.y + 10f,
                labelPaint
            )
            state.y += 16f

            val maxRtt = ping.samples.filter { it.reachable }.maxOfOrNull { it.rttMs }?.coerceAtLeast(5L) ?: 10L
            val boxTop = state.y
            val boxBottom = boxTop + 50f
            val slotW = CONTENT_WIDTH / ping.samples.size.coerceAtLeast(1)
            val barW = (slotW * 0.52f).coerceAtMost(28f)
            val tinyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#334155")
                textSize = 7.8f
                textAlign = Paint.Align.CENTER
            }

            ping.samples.forEachIndexed { idx, s ->
                val cx = MARGIN + idx * slotW + slotW / 2f
                if (s.reachable) {
                    val h = (38f * (s.rttMs.toFloat() / maxRtt.toFloat())).coerceAtLeast(4f)
                    val col = Paint().apply {
                        color = Color.parseColor(
                            when {
                                s.rttMs <= 15L -> "#15803D"
                                s.rttMs <= 45L -> "#D97706"
                                else -> "#B91C1C"
                            }
                        )
                    }
                    state.canvas.drawRoundRect(
                        RectF(cx - barW / 2f, boxBottom - h, cx + barW / 2f, boxBottom),
                        3f,
                        3f,
                        col
                    )
                    state.canvas.drawText("${s.rttMs}ms", cx, boxBottom + 10f, tinyPaint)
                } else {
                    val col = Paint().apply { color = Color.parseColor("#B91C1C") }
                    state.canvas.drawRect(cx - barW / 2f, boxBottom - 3f, cx + barW / 2f, boxBottom, col)
                    state.canvas.drawText("Drop", cx, boxBottom + 10f, tinyPaint)
                }
            }
            state.y = boxBottom + 20f
        }

        state.y += 6f
    }

    private fun severityPdfColor(severity: SecuritySeverity): Int {
        return when (severity) {
            SecuritySeverity.CRITICAL -> Color.parseColor("#B91C1C")
            SecuritySeverity.HIGH -> Color.parseColor("#C2410C")
            SecuritySeverity.MEDIUM -> Color.parseColor("#B45309")
            SecuritySeverity.LOW -> Color.parseColor("#1D4ED8")
            SecuritySeverity.SAFE -> Color.parseColor("#15803D")
        }
    }

    private class PdfCursor(private val document: PdfDocument) {
        private var pageNumber = 0
        private var currentPage: PdfDocument.Page? = null
        lateinit var canvas: android.graphics.Canvas
        var y: Float = MARGIN

        fun startNewPage() {
            finishCurrentPage()
            pageNumber += 1
            val info = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create()
            val page = document.startPage(info)
            currentPage = page
            canvas = page.canvas
            y = MARGIN
        }

        fun finishCurrentPage() {
            val page = currentPage ?: return
            val footerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#64748B")
                textSize = 8.5f
            }
            val linePaint = Paint().apply {
                color = Color.parseColor("#E2E8F0")
                strokeWidth = 0.8f
            }
            canvas.drawLine(MARGIN, PAGE_HEIGHT - 36f, PAGE_WIDTH - MARGIN, PAGE_HEIGHT - 36f, linePaint)
            canvas.drawText("Wi-Fi & Local Network Defensive Audit Report", MARGIN, PAGE_HEIGHT - 22f, footerPaint)
            val pageLabel = "Page $pageNumber"
            val labelW = footerPaint.measureText(pageLabel)
            canvas.drawText(pageLabel, PAGE_WIDTH - MARGIN - labelW, PAGE_HEIGHT - 22f, footerPaint)
            document.finishPage(page)
            currentPage = null
        }

        fun ensureSpace(neededHeight: Float) {
            if (y + neededHeight > BOTTOM_LIMIT) {
                startNewPage()
            }
        }

        fun drawSectionHeader(title: String) {
            ensureSpace(32f)
            val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#0F172A")
                textSize = 12f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            val linePaint = Paint().apply {
                color = Color.parseColor("#94A3B8")
                strokeWidth = 1f
            }
            canvas.drawText(title, MARGIN, y + 12f, headerPaint)
            y += 17f
            canvas.drawLine(MARGIN, y, PAGE_WIDTH - MARGIN, y, linePaint)
            y += 10f
        }

        fun drawKeyValue(label: String, value: String) {
            ensureSpace(16f)
            val keyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#334155")
                textSize = 9.8f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            val prefix = "$label: "
            val prefixWidth = keyPaint.measureText(prefix)
            canvas.drawText(prefix, MARGIN, y + 10f, keyPaint)
            drawWrappedText(
                text = value,
                size = 9.8f,
                color = Color.parseColor("#0F172A"),
                indent = prefixWidth
            )
        }

        fun drawWrappedText(
            text: String,
            size: Float = 10f,
            bold: Boolean = false,
            color: Int = Color.parseColor("#0F172A"),
            indent: Float = 0f
        ) {
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                this.color = color
                textSize = size
                typeface = if (bold) Typeface.create(Typeface.DEFAULT, Typeface.BOLD) else Typeface.DEFAULT
            }
            val maxW = (CONTENT_WIDTH - indent).coerceAtLeast(80f)
            val lineHeight = size + 4.5f
            var start = 0
            val cleanText = text.replace("\n", " ")

            if (cleanText.isEmpty()) {
                y += lineHeight
                return
            }

            while (start < cleanText.length) {
                var count = paint.breakText(cleanText, start, cleanText.length, true, maxW, null)
                if (count <= 0) break

                var end = start + count
                if (end < cleanText.length) {
                    val lastSpace = cleanText.lastIndexOf(' ', end - 1)
                    if (lastSpace > start) {
                        end = lastSpace + 1
                    }
                }

                ensureSpace(lineHeight)
                canvas.drawText(cleanText.substring(start, end).trimEnd(), MARGIN + indent, y + size, paint)
                y += lineHeight
                start = end
                while (start < cleanText.length && cleanText[start] == ' ') {
                    start++
                }
            }
        }
    }
}
