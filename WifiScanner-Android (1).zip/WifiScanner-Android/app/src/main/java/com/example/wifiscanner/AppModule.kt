package com.example.wifiscanner

import org.koin.android.ext.koin.androidApplication
import org.koin.android.ext.koin.androidContext
import org.koin.core.module.dsl.viewModel
import org.koin.dsl.module

val appModule = module {
    single { AuditHistoryDatabase.getInstance(androidContext()) }
    single { get<AuditHistoryDatabase>().auditHistoryDao() }
    single { WifiNetworkScanner(androidContext()) }
    viewModel { WifiAuditViewModel(androidApplication(), get(), get()) }
}
