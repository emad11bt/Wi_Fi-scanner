# Keep Compose, Room, Koin, Retrofit, OkHttp and Kotlinx Serialization models intact
