# Wi-Fi Scanner

Android Kotlin (Jetpack Compose) project built with a full modern Android library stack for defensive Wi-Fi auditing, signal heatmaps, local LAN inspection, encrypted baseline monitoring, biometric audit vault, and custom PDF report export.

## Modern Libraries Integrated

- **Kotlin 2.0.21 + AGP 8.7.3 + KSP 2.0.21-1.0.28 + Gradle 8.9**
- **Jetpack Compose BOM (2024.12.01)**: Material 3, Adaptive WindowSizeClass, Extended Material Icons, Animation
- **Jetpack Navigation Compose (2.8.5)** & **Core SplashScreen (1.0.1)**
- **Koin 4.0 BOM**: Dependency Injection for ViewModel, Room DAO, Scanner, and WorkManager
- **Jetpack Room (2.6.1) + KSP**: Local SQLite Audit History Vault (`AuditHistoryDatabase.kt`)
- **Jetpack DataStore Preferences (1.1.1)** & **WorkManager (2.10.0)**
- **Jetpack Security Crypto (1.0.0)** & **Biometric (1.1.0)**: AES-256 EncryptedSharedPreferences baselines & Fingerprint/PIN Vault guard
- **OkHttp 4.12 + DNS-over-HTTPS + OkHttp-TLS + Retrofit 2.11 + Kotlinx Serialization Converter**: Defensive TLS handshake, DoH posture, and SPKI certificate pinning inspection (`ModernTlsAndDnsInspector.kt`)
- **Multi-Layer Network Inspection & Vulnerability Confirmation Stack (`MultiLayerNetworkInspector.kt`)**:
  - **`dnsjava:dnsjava:3.7.1`**: DNSSEC `AD` flag verification and DNS anti-hijacking cross-comparison against `1.1.1.1`
  - **`org.jmdns:jmdns:3.6.5`**: Local LAN mDNS / ZeroConf service discovery (`_http`, `_ssh`, `_smb`, `_ipp`, `_rtsp`)
  - **`io.ktor:ktor-network:3.1.0` & `ktor-network-tls`**: Non-blocking UDP SSDP/UPnP multicast discovery and safe TCP banner confirmation
  - **`com.github.seancfoley:ipaddress:5.6.2`**: CIDR subnet prefix analysis and locally-administered BSSID/MAC verification
  - **`org.conscrypt:conscrypt-android:2.9.0` & `org.bouncycastle:bcpkix-jdk18on:1.86`**: TLS 1.3 provider & X.509 signature/key-strength audit
  - **`commons-net:commons-net:3.13.0`**: NTP clock-drift guard preventing false-positive certificate errors
- **JetBrains Kotlinx Libraries**: Coroutines `1.9.0`, Serialization JSON `1.7.3`, Collections Immutable `0.3.8`, DateTime `0.6.1`
- **Coil Compose `2.7.0`**, **Lottie Compose `6.6.0`**, **Accompanist Permissions `0.36.0`**, **Timber `5.0.1`**
- **Native Visual Analytics & Embedded PDF Charts (`NetworkAnalyticsCharts.kt` & `PdfReportGenerator.kt`)**: Jetpack Compose signal strength dBm bars, 2.4 GHz channel congestion columns, severity breakdown bar, gateway RTT latency charts, plus embedded vector charts drawn onto exported A4 PDFs (and exportable JSON compatible with the web app's Recharts dashboard).

## Build an APK in Android Studio

1. Extract this ZIP folder.
2. Open **Android Studio** and select **Open** -> choose the extracted folder.
3. Wait for Gradle Sync to download dependencies.
4. Select **Build -> Build Bundle(s) / APK(s) -> Build APK(s)**.
5. Locate `app-debug.apk` under `app/build/outputs/apk/debug/app-debug.apk`.

## Runtime Requirements

- Grant `ACCESS_FINE_LOCATION` permission when prompted.
- Ensure **Wi-Fi** and device **Location Services** are enabled.
- Android 9+ throttles foreground apps to 4 `startScan()` calls every 2 minutes.
